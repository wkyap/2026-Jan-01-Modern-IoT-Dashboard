# IoT Dashboard Self-Service System
## Complete Technical Specification Document

**Version:** 1.0  
**Date:** January 10, 2026  
**Status:** Ready for Implementation

---

# 1. Executive Summary

## 1.1 Project Goal

Build a modern, AI-powered IoT Dashboard Self-Service System that replaces the complexity of ThingsBoard with a simpler, more maintainable architecture while providing superior user experience through AI-assisted features.

## 1.2 Key Differentiators

| Aspect | ThingsBoard | Our System |
|--------|-------------|------------|
| Framework | Angular 18 + NgRx | React 19 + Next.js 15 + Zustand |
| Widget System | Complex lifecycle, subscription management | Simple React components + hooks |
| Dashboard Builder | Configuration-heavy, JSON editing | Drag-drop + AI natural language |
| AI Integration | None | First-class citizen throughout |
| Learning Curve | Steep | Moderate |
| Multi-tenancy | Shared database | Database-per-tenant |

## 1.3 Scale Requirements

| Metric | Target |
|--------|--------|
| Devices | 2,000 - 10,000 |
| Data Throughput | 10-20 MB/second (constant) |
| Concurrent Users | 50+ dashboard users |
| Widgets per Dashboard | ~20 |
| Data Points per Chart | Maximum 50 |
| Region | Asia-Pacific (primary) |

---

# 2. Confirmed Requirements

## 2.1 Core Platform

| Requirement | Decision |
|-------------|----------|
| Users | Internal team + Customers, all technical levels |
| Registration | Self-service signup (basic), Admin-only (advanced features) |
| Tenant Model | Self-service with hierarchy: Organization → Site → Building → Floor → Area |
| Cross-tenant Sharing | No |
| Pricing Tiers | No (single tier for now) |

## 2.2 Device & Data Model

| Requirement | Decision |
|-------------|----------|
| Device Organization | Hierarchical (Site → Building → Floor → Area → Device) |
| Device Profiles/Types | Yes (templates with predefined telemetry keys) |
| Gateway Support | Yes (parent-child device relationships) |
| Telemetry Keys | Predefined per device type |
| Unit Management | Yes (automatic conversion) |
| Attributes | Server-side + Client-side + Shared (push to device) |

## 2.3 Dashboard & Widgets

| Requirement | Decision |
|-------------|----------|
| Dashboard Sharing | Yes (within tenant) |
| Public Dashboards | Yes (view-only, real-time data, no branding) |
| Dashboard Templates | Yes (cloneable) |
| Widget Cross-interaction | No |
| Time Sync Across Widgets | No |
| Dashboard States/Filters | Yes |
| User-specific Customization | Yes |

## 2.4 Alerting & Notifications

| Requirement | Decision |
|-------------|----------|
| Channels | Email, Webhook, In-app, Push (web + mobile future) |
| Alert Complexity | Simple threshold (value > X) |
| Acknowledgment Workflow | Yes |

## 2.5 Device Control (RPC)

| Requirement | Decision |
|-------------|----------|
| Bidirectional | Yes |
| Command Types | All (on/off, parameters, firmware) |
| Execution Mode | Asynchronous |
| Authorization | Role-based |
| Audit Logging | Yes, all commands |

## 2.6 Rule Engine

| Requirement | Decision |
|-------------|----------|
| Complexity | Simple (condition → action) |
| Actions | Create alert, Send notification |

## 2.7 AI Features (All Must Have)

| Feature | Priority |
|---------|----------|
| Natural language dashboard builder | Must Have |
| Natural language data queries | Must Have |
| Anomaly detection with explanations | Must Have |
| Alert summarization (daily digest) | Must Have |
| Predictive maintenance suggestions | Must Have |
| Auto-configuration recommendations | Must Have |
| Smart widget suggestions | Must Have |
| AI Autonomy | Suggest → User Approves |

## 2.8 Data Retention & Storage

| Requirement | Decision |
|-------------|----------|
| Raw Data Retention | 30 days |
| Cold Storage Archival | Yes |
| Cold Storage Retention | 1 year |
| Aggregation Intervals | 1 minute (automatic) |

## 2.9 Integration & Export

| Requirement | Decision |
|-------------|----------|
| External Integrations v1 | None required |
| Export Formats | CSV, JSON, Excel, PDF |
| Bulk Export | Yes |
| Tenant API Access | Yes (REST) |
| API Key Management | Yes, per tenant |

## 2.10 Security & Audit

| Requirement | Decision |
|-------------|----------|
| Security Features | Skip for now (future phase) |
| Audit Logging | Full audit of all user actions |
| Audit Retention | 30 days |

## 2.11 Deployment

| Requirement | Decision |
|-------------|----------|
| Geographic | Multi-region (Asia-Pacific primary) |
| Deployment Model | Self-hosted + Managed cloud (AWS, Azure) |
| Team Experience | Yes (React/Next.js) |
