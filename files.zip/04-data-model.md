# 5. Data Model

## 5.1 Multi-Tenant Database Architecture

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                           MULTI-TENANT DATA MODEL                                    │
├─────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                      │
│  ┌─────────────────────────────────────────────────────────────────────────────┐    │
│  │                         MASTER DATABASE (Shared)                             │    │
│  │                                                                              │    │
│  │   tenants              tenant_databases         global_users                │    │
│  │   ┌────────────────┐   ┌────────────────────┐   ┌────────────────┐          │    │
│  │   │ id (UUID)      │──▶│ tenant_id (FK)     │   │ id             │          │    │
│  │   │ name           │   │ database_host      │   │ email          │          │    │
│  │   │ slug           │   │ database_name      │   │ role           │          │    │
│  │   │ status         │   │ database_user      │   │ created_at     │          │    │
│  │   │ plan           │   │ database_pass (enc)│   └────────────────┘          │    │
│  │   │ created_at     │   │ pool_size          │                               │    │
│  │   │ settings (JSON)│   │ status             │                               │    │
│  │   └────────────────┘   └────────────────────┘                               │    │
│  └─────────────────────────────────────────────────────────────────────────────┘    │
│                                                                                      │
│                          Connection Pool Manager (Dynamic tenant routing)            │
│                                         │                                            │
│           ┌─────────────────────────────┼─────────────────────────────┐              │
│           ▼                             ▼                             ▼              │
│  ┌─────────────────┐           ┌─────────────────┐           ┌─────────────────┐    │
│  │  Tenant A DB    │           │  Tenant B DB    │           │  Tenant C DB    │    │
│  │  (PostgreSQL)   │           │  (PostgreSQL)   │           │  (PostgreSQL)   │    │
│  └─────────────────┘           └─────────────────┘           └─────────────────┘    │
│                                                                                      │
│  ┌─────────────────────────────────────────────────────────────────────────────┐    │
│  │               TimescaleDB (Shared - Tenant Isolation via tenant_id)          │    │
│  │                                                                              │    │
│  │   telemetry (Hypertable)                                                    │    │
│  │   ┌────────────────────────────────────────────────────────────────────┐    │    │
│  │   │ time (TIMESTAMPTZ) | tenant_id (UUID) | device_id | key | value   │    │    │
│  │   └────────────────────────────────────────────────────────────────────┘    │    │
│  │                                                                              │    │
│  │   Row-Level Security (RLS) enforces tenant_id isolation                     │    │
│  │   Continuous Aggregates: telemetry_1min, telemetry_1hour, telemetry_1day   │    │
│  │   Retention: 30 days raw → Archive to S3 Glacier                           │    │
│  └─────────────────────────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

## 5.2 Master Database Schema

```sql
-- Master database for tenant management
-- Database: iot_master

-- Tenants table
CREATE TABLE tenants (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(100) UNIQUE NOT NULL,
    status VARCHAR(20) DEFAULT 'active', -- active, suspended, deleted
    plan VARCHAR(50) DEFAULT 'standard',
    settings JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Tenant database connections
CREATE TABLE tenant_databases (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    database_host VARCHAR(255) NOT NULL,
    database_port INTEGER DEFAULT 5432,
    database_name VARCHAR(100) NOT NULL,
    database_user VARCHAR(100) NOT NULL,
    database_password_encrypted TEXT NOT NULL,
    connection_pool_size INTEGER DEFAULT 10,
    status VARCHAR(20) DEFAULT 'active',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Global super admins (platform owners)
CREATE TABLE global_users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) UNIQUE NOT NULL,
    name VARCHAR(255),
    role VARCHAR(50) DEFAULT 'super_admin',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_tenants_slug ON tenants(slug);
CREATE INDEX idx_tenants_status ON tenants(status);
CREATE INDEX idx_tenant_databases_tenant ON tenant_databases(tenant_id);
```

## 5.3 Tenant Database Schema

```sql
-- ============================================
-- ORGANIZATION HIERARCHY
-- ============================================

-- Sites (top level)
CREATE TABLE sites (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    address TEXT,
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    timezone VARCHAR(50) DEFAULT 'UTC',
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Buildings
CREATE TABLE buildings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    site_id UUID REFERENCES sites(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Floors
CREATE TABLE floors (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    building_id UUID REFERENCES buildings(id) ON DELETE CASCADE,
    name VARCHAR(100) NOT NULL,
    level INTEGER,
    floor_plan_url TEXT,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Areas
CREATE TABLE areas (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    floor_id UUID REFERENCES floors(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- USER MANAGEMENT
-- ============================================

-- Roles
CREATE TABLE roles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(100) NOT NULL,
    description TEXT,
    permissions JSONB NOT NULL DEFAULT '[]',
    is_system BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Default system roles
INSERT INTO roles (name, description, permissions, is_system) VALUES
('tenant_admin', 'Full access to all tenant resources', '["*"]', true),
('dashboard_manager', 'Can create and manage dashboards', 
 '["dashboard:*", "widget:*", "device:read", "telemetry:read", "alert:read,create,update"]', true),
('operator', 'Can view dashboards and control devices', 
 '["dashboard:read", "device:read,update", "telemetry:read", "alert:read,update"]', true),
('viewer', 'Read-only access to dashboards', 
 '["dashboard:read", "device:read", "telemetry:read", "alert:read"]', true);

-- Users
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) UNIQUE NOT NULL,
    name VARCHAR(255),
    avatar_url TEXT,
    role_id UUID REFERENCES roles(id),
    email_verified BOOLEAN DEFAULT FALSE,
    status VARCHAR(20) DEFAULT 'active',
    last_login TIMESTAMPTZ,
    settings JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- DEVICE MANAGEMENT
-- ============================================

-- Device profiles/types
CREATE TABLE device_profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    type VARCHAR(100) NOT NULL, -- sensor, actuator, gateway, controller
    telemetry_keys JSONB NOT NULL DEFAULT '[]',
    -- Example: [{"key": "temperature", "type": "number", "unit": "°C"}]
    attribute_keys JSONB NOT NULL DEFAULT '[]',
    command_types JSONB NOT NULL DEFAULT '[]',
    -- Example: [{"name": "reboot", "params": []}]
    default_alert_rules JSONB DEFAULT '[]',
    icon VARCHAR(100),
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Devices
CREATE TABLE devices (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    profile_id UUID REFERENCES device_profiles(id),
    area_id UUID REFERENCES areas(id),
    parent_device_id UUID REFERENCES devices(id), -- For gateway relationships
    
    name VARCHAR(255) NOT NULL,
    label VARCHAR(255),
    description TEXT,
    
    -- Credentials
    access_token VARCHAR(255) UNIQUE,
    credentials_type VARCHAR(50) DEFAULT 'access_token',
    credentials_data JSONB DEFAULT '{}',
    
    -- Status
    status VARCHAR(20) DEFAULT 'inactive', -- active, inactive, maintenance
    is_gateway BOOLEAN DEFAULT FALSE,
    last_activity TIMESTAMPTZ,
    last_connect TIMESTAMPTZ,
    last_disconnect TIMESTAMPTZ,
    
    -- Attributes
    server_attributes JSONB DEFAULT '{}',
    shared_attributes JSONB DEFAULT '{}',
    
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Device client attributes (reported by device)
CREATE TABLE device_client_attributes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    device_id UUID REFERENCES devices(id) ON DELETE CASCADE,
    key VARCHAR(255) NOT NULL,
    value JSONB NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(device_id, key)
);

-- ============================================
-- DASHBOARD & WIDGETS
-- ============================================

-- Dashboards
CREATE TABLE dashboards (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    
    -- Layout and configuration
    layout JSONB NOT NULL DEFAULT '{"columns": 12, "rowHeight": 80}',
    settings JSONB DEFAULT '{}',
    
    -- Sharing
    is_public BOOLEAN DEFAULT FALSE,
    public_token VARCHAR(255) UNIQUE,
    
    -- States/Filters
    states JSONB DEFAULT '[]',
    
    -- Ownership
    created_by UUID REFERENCES users(id),
    updated_by UUID REFERENCES users(id),
    
    -- Template
    is_template BOOLEAN DEFAULT FALSE,
    template_id UUID REFERENCES dashboards(id),
    
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Widgets
CREATE TABLE widgets (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    dashboard_id UUID REFERENCES dashboards(id) ON DELETE CASCADE,
    
    type VARCHAR(100) NOT NULL,
    title VARCHAR(255),
    
    -- Position (grid-based)
    position JSONB NOT NULL, -- {"x": 0, "y": 0, "w": 4, "h": 3}
    
    -- Data source configuration
    data_source JSONB NOT NULL DEFAULT '{}',
    
    -- Widget-specific configuration
    config JSONB DEFAULT '{}',
    
    -- Styling
    style JSONB DEFAULT '{}',
    
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- User dashboard customizations
CREATE TABLE user_dashboard_settings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    dashboard_id UUID REFERENCES dashboards(id) ON DELETE CASCADE,
    widget_positions JSONB DEFAULT '{}',
    hidden_widgets UUID[] DEFAULT '{}',
    settings JSONB DEFAULT '{}',
    UNIQUE(user_id, dashboard_id)
);

-- Dashboard shares
CREATE TABLE dashboard_shares (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    dashboard_id UUID REFERENCES dashboards(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    permission VARCHAR(20) DEFAULT 'view',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(dashboard_id, user_id)
);

-- ============================================
-- ALERTING SYSTEM
-- ============================================

-- Alert rules
CREATE TABLE alert_rules (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    
    -- Condition
    device_profile_id UUID REFERENCES device_profiles(id),
    device_ids UUID[],
    telemetry_key VARCHAR(255) NOT NULL,
    condition_type VARCHAR(50) NOT NULL, -- gt, gte, lt, lte, eq, neq
    threshold DECIMAL NOT NULL,
    duration_seconds INTEGER DEFAULT 0,
    
    -- Alert settings
    severity VARCHAR(20) DEFAULT 'warning', -- info, warning, critical
    
    -- Notifications
    notification_channels JSONB DEFAULT '["in_app"]',
    notification_config JSONB DEFAULT '{}',
    
    is_active BOOLEAN DEFAULT TRUE,
    
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Alert instances
CREATE TABLE alerts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    rule_id UUID REFERENCES alert_rules(id),
    device_id UUID REFERENCES devices(id),
    
    severity VARCHAR(20) NOT NULL,
    status VARCHAR(20) DEFAULT 'active', -- active, acknowledged, resolved
    
    telemetry_key VARCHAR(255),
    trigger_value DECIMAL,
    threshold DECIMAL,
    message TEXT,
    
    triggered_at TIMESTAMPTZ DEFAULT NOW(),
    acknowledged_at TIMESTAMPTZ,
    acknowledged_by UUID REFERENCES users(id),
    resolved_at TIMESTAMPTZ,
    resolved_by UUID REFERENCES users(id),
    
    notes TEXT
);

-- ============================================
-- RULE ENGINE
-- ============================================

CREATE TABLE rules (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    
    trigger_type VARCHAR(50) NOT NULL, -- telemetry, device_status, schedule
    trigger_config JSONB NOT NULL,
    
    actions JSONB NOT NULL DEFAULT '[]',
    
    is_active BOOLEAN DEFAULT TRUE,
    
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- DEVICE COMMANDS (RPC)
-- ============================================

CREATE TABLE device_commands (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    device_id UUID REFERENCES devices(id) ON DELETE CASCADE,
    
    command_type VARCHAR(100) NOT NULL,
    params JSONB DEFAULT '{}',
    
    status VARCHAR(20) DEFAULT 'pending', -- pending, sent, success, failed, timeout
    
    sent_at TIMESTAMPTZ,
    response JSONB,
    completed_at TIMESTAMPTZ,
    error_message TEXT,
    
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- API KEYS
-- ============================================

CREATE TABLE api_keys (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    key_hash VARCHAR(255) UNIQUE NOT NULL,
    key_prefix VARCHAR(10) NOT NULL,
    
    permissions JSONB DEFAULT '["read"]',
    
    last_used_at TIMESTAMPTZ,
    expires_at TIMESTAMPTZ,
    
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    revoked_at TIMESTAMPTZ
);

-- ============================================
-- AUDIT LOG
-- ============================================

CREATE TABLE audit_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id),
    
    action VARCHAR(100) NOT NULL,
    resource_type VARCHAR(100) NOT NULL,
    resource_id UUID,
    
    details JSONB DEFAULT '{}',
    ip_address INET,
    user_agent TEXT,
    
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- INDEXES
-- ============================================

CREATE INDEX idx_buildings_site ON buildings(site_id);
CREATE INDEX idx_floors_building ON floors(building_id);
CREATE INDEX idx_areas_floor ON areas(floor_id);
CREATE INDEX idx_devices_profile ON devices(profile_id);
CREATE INDEX idx_devices_area ON devices(area_id);
CREATE INDEX idx_devices_parent ON devices(parent_device_id);
CREATE INDEX idx_devices_status ON devices(status);
CREATE INDEX idx_devices_token ON devices(access_token);
CREATE INDEX idx_widgets_dashboard ON widgets(dashboard_id);
CREATE INDEX idx_alerts_status ON alerts(status);
CREATE INDEX idx_alerts_triggered ON alerts(triggered_at);
CREATE INDEX idx_commands_device ON device_commands(device_id);
CREATE INDEX idx_audit_user ON audit_logs(user_id);
CREATE INDEX idx_audit_created ON audit_logs(created_at);
```

## 5.4 TimescaleDB Schema

```sql
-- Enable TimescaleDB extension
CREATE EXTENSION IF NOT EXISTS timescaledb;

-- Main telemetry hypertable
CREATE TABLE telemetry (
    time TIMESTAMPTZ NOT NULL,
    tenant_id UUID NOT NULL,
    device_id UUID NOT NULL,
    key VARCHAR(255) NOT NULL,
    value_numeric DOUBLE PRECISION,
    value_string TEXT,
    value_boolean BOOLEAN,
    value_json JSONB
);

-- Convert to hypertable
SELECT create_hypertable('telemetry', 'time', 
    chunk_time_interval => INTERVAL '1 day',
    if_not_exists => TRUE
);

-- Indexes
CREATE INDEX idx_telemetry_tenant_device_key_time 
ON telemetry (tenant_id, device_id, key, time DESC);

-- Enable compression
ALTER TABLE telemetry SET (
    timescaledb.compress,
    timescaledb.compress_segmentby = 'tenant_id, device_id, key'
);

SELECT add_compression_policy('telemetry', INTERVAL '7 days');

-- Continuous aggregate for 1-minute averages
CREATE MATERIALIZED VIEW telemetry_1min
WITH (timescaledb.continuous) AS
SELECT
    time_bucket('1 minute', time) AS bucket,
    tenant_id,
    device_id,
    key,
    AVG(value_numeric) AS avg_value,
    MIN(value_numeric) AS min_value,
    MAX(value_numeric) AS max_value,
    COUNT(*) AS count
FROM telemetry
WHERE value_numeric IS NOT NULL
GROUP BY bucket, tenant_id, device_id, key
WITH NO DATA;

SELECT add_continuous_aggregate_policy('telemetry_1min',
    start_offset => INTERVAL '1 hour',
    end_offset => INTERVAL '1 minute',
    schedule_interval => INTERVAL '1 minute'
);

-- Retention policy: 30 days
SELECT add_retention_policy('telemetry', INTERVAL '30 days');

-- Row-Level Security
ALTER TABLE telemetry ENABLE ROW LEVEL SECURITY;

CREATE POLICY tenant_isolation ON telemetry
    USING (tenant_id = current_setting('app.current_tenant_id')::uuid);
```
