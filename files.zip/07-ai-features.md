# 7. AI Features Specification

## 7.1 AI Features Overview

| Feature | Description | Priority |
|---------|-------------|----------|
| Natural Language Dashboard Builder | Create dashboards by describing what you need | Must Have |
| Natural Language Data Queries | Ask questions about your data in plain English | Must Have |
| Anomaly Detection | Automatic detection with AI explanations | Must Have |
| Alert Summarization | Daily digest with grouped alerts and insights | Must Have |
| Predictive Maintenance | Predict equipment failures before they happen | Must Have |
| Auto-Configuration | Suggest optimal settings for new devices | Must Have |
| Smart Widget Suggestions | Recommend widgets based on data patterns | Must Have |

**AI Autonomy Rule:** All AI suggestions require user approval before being applied.

## 7.2 Natural Language Dashboard Builder

### Example Flow

```
User: "Create a dashboard showing temperature and humidity from all sensors 
       in Production Line 1, with alerts when temperature > 35°C"

                    ↓ Intent Recognition
                    
Action: Create dashboard
Entities: temperature, humidity sensors
Location: Production Line 1
Additional: Alert rule (temperature > 35°C)

                    ↓ Context Gathering
                    
Query device profiles → Find matching devices → Get telemetry keys

                    ↓ Schema Generation (Claude API)
                    
Generate dashboard config with widgets + alert rules

                    ↓ Preview & Confirmation
                    
Show preview → [Apply] [Modify] [Cancel]
```

### Claude API Prompt Template

```
You are an IoT dashboard configuration assistant.
Generate dashboard configurations in JSON format.

Available device profiles: {deviceProfiles}
Location hierarchy: {locations}
Telemetry keys: {telemetryKeys}

Output: { dashboard: {...}, alertRules: [...], explanation: "..." }
```

## 7.3 Natural Language Data Queries

### Example Queries

| User Query | Generated Action |
|------------|------------------|
| "What was the average temperature last week?" | SQL query + value display |
| "Show me power consumption by building" | SQL query + bar chart |
| "Which devices had the most alerts yesterday?" | SQL query + table |
| "Compare humidity between Building A and B" | SQL query + comparison chart |

## 7.4 Anomaly Detection

### Methods

| Method | Use Case |
|--------|----------|
| Z-Score | Point anomalies (values far from mean) |
| IQR | Outlier detection |
| Moving Average | Trend deviations |
| Seasonal | Periodic pattern anomalies |

### Implementation

```typescript
// Z-Score based anomaly detection
function detectAnomalies(data, sensitivity = 3) {
  const mean = average(data);
  const stddev = standardDeviation(data);
  
  return data.filter(value => {
    const zscore = Math.abs((value - mean) / stddev);
    return zscore > sensitivity;
  });
}
```

### AI Explanation

For each detected anomaly, Claude generates:
1. Likely cause (1-2 sentences)
2. Recommended action (1-2 sentences)

## 7.5 Alert Summarization

### Daily Digest Format

```
📧 IoT Dashboard - Daily Alert Summary
January 10, 2026

🔴 CRITICAL ISSUES (2)
─────────────────────
1. Production Line 3 - Motor Temperature
   Exceeded 85°C for 45 minutes
   → Recommended: Schedule maintenance inspection

🟡 WARNINGS (12)
─────────────────
• Power fluctuations in Building A (8 events)
  Pattern: HVAC cycling issue suspected

📊 SYSTEM HEALTH: 94%
─────────────────────
• Devices Online: 847/862
• Data Quality: 99.2%
```

## 7.6 Auto-Configuration

When a new device is added, AI analyzes:
- Device type and profile
- Historical data from similar devices
- Existing alert rules

And suggests:
- Optimal alert thresholds
- Recommended dashboard widgets
- Aggregation settings

## 7.7 AI Approval Flow

All AI suggestions show:
1. Confidence score (0-100%)
2. Explanation of what will be created/changed
3. Preview of the result
4. Action buttons: [Apply] [Modify] [Reject]

```typescript
interface AISuggestion {
  type: 'dashboard' | 'alert' | 'config' | 'widget';
  suggestion: any;
  explanation: string;
  confidence: number; // 0-1
  onApprove: () => void;
  onModify: () => void;
  onReject: () => void;
}
```
