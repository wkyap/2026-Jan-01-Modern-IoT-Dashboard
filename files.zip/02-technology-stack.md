# 3. Technology Stack

## 3.1 Frontend Stack

| Component | Technology | Version | Rationale |
|-----------|------------|---------|-----------|
| Framework | Next.js (App Router) | 15.x | Server components, streaming, excellent DX |
| Language | TypeScript | 5.x | Type safety, better tooling |
| Styling | Tailwind CSS | 4.x | Utility-first, excellent performance |
| UI Components | shadcn/ui + Radix UI | Latest | Accessible, customizable, no lock-in |
| State (Client) | Zustand | 5.x | Simple, minimal boilerplate |
| State (Server) | TanStack Query | 5.x | Caching, real-time sync |
| Charts | Recharts | 2.x | React-native, good performance |
| Tables | TanStack Table | 8.x | Headless, highly customizable |
| Maps | Mapbox GL JS | 3.x | Best performance for large datasets |
| Drag & Drop | dnd-kit | 6.x | Modern, accessible, performant |
| Forms | React Hook Form + Zod | 7.x + 3.x | Type-safe validation |
| Real-time | Socket.io Client | 4.x | Reliable WebSocket abstraction |
| Icons | Lucide React | Latest | Consistent, tree-shakeable |
| Date/Time | date-fns | 3.x | Modular, lightweight |
| Notifications | Sonner | Latest | Modern toast notifications |

## 3.2 Backend Stack

| Component | Technology | Version | Rationale |
|-----------|------------|---------|-----------|
| Runtime | Node.js | 22 LTS | Latest features, excellent ecosystem |
| Framework | Next.js API Routes | 15.x | Unified frontend/backend |
| Type-safe API | tRPC | 11.x | End-to-end type safety |
| Authentication | Auth.js (NextAuth) | 5.x | OAuth providers, session management |
| Real-time | Socket.io Server | 4.x | Room-based pub/sub |
| Background Jobs | BullMQ | 5.x | Reliable job processing |
| Message Broker | Redpanda | Latest | Kafka-compatible, lower resources |
| Stream Processing | Benthos | 4.x | Lightweight, declarative pipelines |
| Email | Resend | Latest | Modern email API |
| Push Notifications | Web Push + Firebase | Latest | Browser + mobile push |

## 3.3 IoT Gateway Stack

| Component | Technology | Version | Rationale |
|-----------|------------|---------|-----------|
| MQTT Broker | EMQX | 5.x | High performance, clustering |
| HTTP Ingestion | Custom (Node.js) | - | Webhook support, validation |
| CoAP Gateway | node-coap | Latest | Constrained device support |
| LwM2M Server | Leshan | 2.x | Device management protocol |
| Modbus Gateway | modbus-serial | Latest | Industrial protocol support |
| OPC-UA | node-opcua | Latest | Industrial automation |

## 3.4 Data Layer Stack

| Component | Technology | Version | Rationale |
|-----------|------------|---------|-----------|
| Primary Database | PostgreSQL | 16.x | Reliable, feature-rich |
| Time-Series | TimescaleDB | 2.x | Native PostgreSQL extension |
| ORM | Prisma | 5.x | Type-safe queries, migrations |
| Cache | Redis | 7.x | Session, cache, pub/sub |
| Object Storage | MinIO | Latest | S3-compatible, self-hosted |
| Cold Storage | S3 Glacier | - | Long-term archival |

## 3.5 AI/ML Stack

| Component | Technology | Rationale |
|-----------|------------|-----------|
| LLM | Claude API (Anthropic) | Best reasoning, function calling |
| Vector Search | pgvector | PostgreSQL native |
| Statistical Analysis | simple-statistics | Lightweight anomaly detection |
| Forecasting | Prophet (Python microservice) | Time-series forecasting |

## 3.6 DevOps Stack

| Component | Technology | Rationale |
|-----------|------------|-----------|
| Containerization | Docker | Development parity |
| Orchestration | Kubernetes | Scaling, self-healing |
| API Gateway | Traefik | Auto-discovery, SSL |
| Monitoring | Prometheus + Grafana | Industry standard |
| Logging | Loki | Grafana integration |
| CI/CD | GitHub Actions | Repository integration |

## 3.7 Protocol Support Matrix

| Protocol | Port | Use Case | Implementation |
|----------|------|----------|----------------|
| MQTT | 1883/8883 | Primary IoT protocol | EMQX Broker |
| MQTT-WS | 8083/8084 | Browser-based devices | EMQX WebSocket |
| HTTP | 80/443 | Webhooks, simple devices | Next.js API Routes |
| CoAP | 5683/5684 | Constrained devices | node-coap |
| LwM2M | 5683 | Device management | Eclipse Leshan |
| Modbus TCP | 502 | Industrial devices | modbus-serial |
| OPC-UA | 4840 | Industrial automation | node-opcua |
