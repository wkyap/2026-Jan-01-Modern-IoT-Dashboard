# 10. Device Simulator (Standalone Tool)

## 10.1 Overview

The Device Simulator is a standalone tool for generating realistic IoT telemetry data for testing and demonstration purposes. It runs independently from the main platform and can simulate thousands of devices with various behaviors.

## 10.2 Simulator Architecture

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                           DEVICE SIMULATOR                                           │
├─────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                      │
│  ┌─────────────────────────────────────────────────────────────────────────────┐    │
│  │                         Simulator Web UI                                     │    │
│  │                                                                              │    │
│  │  ┌───────────────────────────────────────────────────────────────────────┐  │    │
│  │  │  Simulation Control Panel                                              │  │    │
│  │  │                                                                        │  │    │
│  │  │  [+ New Simulation]  [Import Config]  [Export Config]                 │  │    │
│  │  │                                                                        │  │    │
│  │  │  ┌────────────────────────────────────────────────────────────────┐   │  │    │
│  │  │  │ Simulation: Smart Factory          Status: ▶ Running          │   │  │    │
│  │  │  │ Devices: 880    Messages/sec: 15,420    Data: 14.2 MB/s       │   │  │    │
│  │  │  │ [Pause] [Stop] [Configure] [Inject Anomaly]                   │   │  │    │
│  │  │  └────────────────────────────────────────────────────────────────┘   │  │    │
│  │  │                                                                        │  │    │
│  │  │  ┌────────────────────────────────────────────────────────────────┐   │  │    │
│  │  │  │ Simulation: Smart Building         Status: ⏸ Paused           │   │  │    │
│  │  │  │ Devices: 1,100  Messages/sec: 0         Data: 0 MB/s          │   │  │    │
│  │  │  │ [Resume] [Stop] [Configure] [Inject Anomaly]                  │   │  │    │
│  │  │  └────────────────────────────────────────────────────────────────┘   │  │    │
│  │  └───────────────────────────────────────────────────────────────────────┘  │    │
│  └─────────────────────────────────────────────────────────────────────────────┘    │
│                                                                                      │
│  ┌─────────────────────────────────────────────────────────────────────────────┐    │
│  │                         Simulator Engine                                     │    │
│  │                                                                              │    │
│  │  ┌───────────────┐  ┌───────────────┐  ┌───────────────┐                    │    │
│  │  │  Simulation   │  │   Device      │  │   Scenario    │                    │    │
│  │  │  Manager      │  │   Factory     │  │   Engine      │                    │    │
│  │  └───────────────┘  └───────────────┘  └───────────────┘                    │    │
│  │                                                                              │    │
│  │  ┌───────────────┐  ┌───────────────┐  ┌───────────────┐                    │    │
│  │  │   Data        │  │   Protocol    │  │   Metrics     │                    │    │
│  │  │   Generator   │  │   Adapters    │  │   Collector   │                    │    │
│  │  └───────────────┘  └───────────────┘  └───────────────┘                    │    │
│  └─────────────────────────────────────────────────────────────────────────────┘    │
│                                                                                      │
│  ┌─────────────────────────────────────────────────────────────────────────────┐    │
│  │                         Protocol Adapters                                    │    │
│  │                                                                              │    │
│  │  ┌───────────────┐  ┌───────────────┐  ┌───────────────┐                    │    │
│  │  │     MQTT      │  │     HTTP      │  │     CoAP      │                    │    │
│  │  │   Publisher   │  │   Sender      │  │   Client      │                    │    │
│  │  └───────────────┘  └───────────────┘  └───────────────┘                    │    │
│  └─────────────────────────────────────────────────────────────────────────────┘    │
│                                                                                      │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

## 10.3 Pre-built Simulation Templates

### Template 1: Smart Factory

| Category | Device Type | Count | Total |
|----------|-------------|-------|-------|
| Production Lines (4) | Industrial Motor | 40 | |
| | Temperature Sensor | 80 | |
| | Pressure Sensor | 40 | |
| | Flow Meter | 20 | |
| | Power Meter | 20 | |
| Quality Control | Air Quality Sensor | 10 | |
| Warehouse | Humidity Sensor | 40 | |
| | Occupancy Sensor | 20 | |
| Infrastructure | IoT Gateway | 10 | |
| | | | **880** |

**Data Generation:**
- Messages per second: ~15,000
- Data throughput: ~14 MB/s
- Telemetry interval: 500ms - 5s depending on device type

### Template 2: Smart Building

| Category | Device Type | Count | Total |
|----------|-------------|-------|-------|
| HVAC (50 zones) | HVAC Unit | 50 | |
| | Temperature Sensor | 200 | |
| | Humidity Sensor | 100 | |
| Lighting | Lighting Controller | 200 | |
| Security | Occupancy Sensor | 100 | |
| Energy | Power Meter | 100 | |
| Air Quality | Air Quality Sensor | 50 | |
| Infrastructure | IoT Gateway | 20 | |
| | | | **1,100** |

### Template 3: Fleet Management

| Category | Device Type | Count | Total |
|----------|-------------|-------|-------|
| Vehicles | Vehicle GPS | 200 | |
| | Vehicle OBD | 200 | |
| Trailers | Temperature Sensor | 100 | |
| Infrastructure | IoT Gateway | 20 | |
| | | | **520** |

### Template 4: Agriculture

| Category | Device Type | Count | Total |
|----------|-------------|-------|-------|
| Fields (10) | Soil Sensor | 200 | |
| | Weather Station | 20 | |
| | Humidity Sensor | 100 | |
| Irrigation | Flow Meter | 50 | |
| Infrastructure | IoT Gateway | 30 | |
| | | | **600** |

## 10.4 Data Generation Patterns

### Generator Types

```typescript
// simulator/generators/index.ts

export type GeneratorType =
  | 'constant'      // Fixed value
  | 'random'        // Random within range
  | 'gaussian'      // Normal distribution
  | 'sine'          // Sinusoidal pattern
  | 'trend'         // Linear trend over time
  | 'step'          // Step changes at intervals
  | 'schedule'      // Time-based schedule
  | 'correlated'    // Correlated with another key
  | 'accumulator'   // Cumulative value
  | 'replay'        // Replay from file
  | 'gps_path';     // GPS coordinate path

interface GeneratorConfig {
  type: GeneratorType;
  // Type-specific parameters
  [key: string]: any;
}
```

### Generator Examples

```typescript
// Constant value
{ type: 'constant', value: 22 }

// Random within range
{ type: 'random', min: 20, max: 30, decimals: 1 }

// Gaussian distribution
{ type: 'gaussian', mean: 25, stddev: 3, min: 15, max: 35 }

// Sinusoidal (temperature varying through day)
{ type: 'sine', base: 25, amplitude: 5, period: 86400, phase: -6 }

// Linear trend (battery draining)
{ type: 'trend', start: 100, end: 0, duration: 86400 * 7 }

// Step changes (motor RPM)
{ 
  type: 'step', 
  values: [0, 1500, 3000, 1500, 0], 
  durations: [60, 300, 300, 60] 
}

// Time-based schedule (occupancy)
{ 
  type: 'schedule', 
  schedule: { 
    '08:00': true, 
    '12:00': false, 
    '13:00': true, 
    '18:00': false 
  }
}

// Correlated with another value
{ 
  type: 'correlated', 
  baseKey: 'rpm', 
  factor: 0.02, 
  offset: 25, 
  noise: 0.5,
  lag: 30 
}

// Cumulative (energy meter)
{ type: 'accumulator', rateKey: 'power', factor: 1/3600 }

// GPS path simulation
{ 
  type: 'gps_path', 
  startLat: 1.3521, 
  startLng: 103.8198, 
  pathType: 'random_walk',
  speedKmh: 40 
}
```

## 10.5 Anomaly Injection

### Predefined Scenarios

```typescript
// simulator/scenarios/anomalies.ts

export const ANOMALY_SCENARIOS = {
  temperature_spike: {
    name: 'Temperature Spike',
    description: 'Sudden temperature increase',
    duration: 300, // 5 minutes
    targetProfiles: ['temperature_sensor', 'industrial_motor'],
    effects: [{
      key: 'temperature',
      modification: { type: 'multiply', factor: 1.5 }
    }],
  },
  
  sensor_offline: {
    name: 'Sensor Offline',
    description: 'Device stops sending data',
    duration: 600, // 10 minutes
    targetProfiles: ['*'],
    effects: [{
      modification: { type: 'offline' }
    }],
  },
  
  gradual_degradation: {
    name: 'Equipment Degradation',
    description: 'Gradual performance decline',
    duration: 86400, // 24 hours
    targetProfiles: ['industrial_motor'],
    effects: [
      { key: 'vibration', modification: { type: 'trend', factor: 2 } },
      { key: 'temperature', modification: { type: 'trend', factor: 1.3 } },
    ],
  },
  
  power_fluctuation: {
    name: 'Power Fluctuation',
    description: 'Unstable power supply',
    duration: 60,
    targetProfiles: ['power_meter'],
    effects: [{
      key: 'voltage',
      modification: { type: 'oscillate', amplitude: 20, frequency: 2 }
    }],
  },
  
  data_drift: {
    name: 'Sensor Drift',
    description: 'Gradual calibration drift',
    duration: 86400 * 7, // 1 week
    targetProfiles: ['temperature_sensor', 'pressure_sensor'],
    effects: [{
      key: '*',
      modification: { type: 'drift', rate: 0.01 }
    }],
  },
  
  network_latency: {
    name: 'Network Latency',
    description: 'Delayed data transmission',
    duration: 1800, // 30 minutes
    targetProfiles: ['*'],
    effects: [{
      modification: { type: 'delay', minMs: 5000, maxMs: 30000 }
    }],
  },
};
```

## 10.6 Simulator Implementation

### Core Classes

```typescript
// simulator/core/simulation.ts

export class Simulation {
  id: string;
  name: string;
  status: 'running' | 'paused' | 'stopped';
  devices: SimulatedDevice[];
  config: SimulationConfig;
  metrics: SimulationMetrics;
  
  private intervalId?: NodeJS.Timeout;
  private protocolAdapter: ProtocolAdapter;
  
  constructor(config: SimulationConfig) {
    this.id = generateId();
    this.name = config.name;
    this.status = 'stopped';
    this.config = config;
    this.devices = [];
    this.metrics = {
      messagesPerSecond: 0,
      bytesPerSecond: 0,
      totalMessages: 0,
      errors: 0,
    };
    
    this.protocolAdapter = createProtocolAdapter(config.protocol);
  }
  
  async start() {
    if (this.status === 'running') return;
    
    // Connect to broker/endpoint
    await this.protocolAdapter.connect(this.config.connection);
    
    // Create devices
    this.devices = createDevicesFromTemplate(this.config.template);
    
    // Start generation loop
    this.status = 'running';
    this.runLoop();
  }
  
  private runLoop() {
    const tickMs = 100; // 100ms tick rate
    
    this.intervalId = setInterval(async () => {
      if (this.status !== 'running') return;
      
      const now = Date.now();
      const messages: TelemetryMessage[] = [];
      
      for (const device of this.devices) {
        if (device.shouldSend(now)) {
          const telemetry = device.generateTelemetry(now);
          messages.push({
            deviceId: device.id,
            accessToken: device.accessToken,
            ...telemetry,
          });
        }
      }
      
      if (messages.length > 0) {
        await this.protocolAdapter.sendBatch(messages);
        this.updateMetrics(messages);
      }
    }, tickMs);
  }
  
  pause() {
    this.status = 'paused';
  }
  
  resume() {
    this.status = 'running';
  }
  
  async stop() {
    this.status = 'stopped';
    if (this.intervalId) {
      clearInterval(this.intervalId);
    }
    await this.protocolAdapter.disconnect();
  }
  
  injectAnomaly(scenario: AnomalyScenario, targetDeviceIds?: string[]) {
    const targets = targetDeviceIds
      ? this.devices.filter(d => targetDeviceIds.includes(d.id))
      : this.devices.filter(d => 
          scenario.targetProfiles.includes('*') ||
          scenario.targetProfiles.includes(d.profileType)
        );
    
    for (const device of targets) {
      device.applyAnomaly(scenario);
    }
    
    // Schedule anomaly removal
    setTimeout(() => {
      for (const device of targets) {
        device.clearAnomaly();
      }
    }, scenario.duration * 1000);
  }
}
```

### Simulated Device

```typescript
// simulator/core/device.ts

export class SimulatedDevice {
  id: string;
  name: string;
  profileType: string;
  accessToken: string;
  generators: Map<string, DataGenerator>;
  lastSendTime: number = 0;
  sendInterval: number;
  activeAnomaly?: AnomalyScenario;
  
  constructor(config: DeviceConfig) {
    this.id = config.id || generateId();
    this.name = config.name;
    this.profileType = config.profileType;
    this.accessToken = config.accessToken || generateToken();
    this.sendInterval = config.sendInterval;
    
    this.generators = new Map();
    for (const key of config.telemetryKeys) {
      this.generators.set(key.key, createGenerator(key.generator));
    }
  }
  
  shouldSend(now: number): boolean {
    return now - this.lastSendTime >= this.sendInterval;
  }
  
  generateTelemetry(now: number): { ts: number; values: Record<string, any> } {
    this.lastSendTime = now;
    
    const values: Record<string, any> = {};
    
    for (const [key, generator] of this.generators) {
      let value = generator.generate(now);
      
      // Apply anomaly modification if active
      if (this.activeAnomaly) {
        value = this.applyAnomalyEffect(key, value);
      }
      
      values[key] = value;
    }
    
    return { ts: now, values };
  }
  
  applyAnomaly(scenario: AnomalyScenario) {
    this.activeAnomaly = scenario;
  }
  
  clearAnomaly() {
    this.activeAnomaly = undefined;
  }
  
  private applyAnomalyEffect(key: string, value: any): any {
    if (!this.activeAnomaly) return value;
    
    for (const effect of this.activeAnomaly.effects) {
      if (effect.key === '*' || effect.key === key) {
        switch (effect.modification.type) {
          case 'multiply':
            return value * effect.modification.factor;
          case 'add':
            return value + effect.modification.offset;
          case 'offline':
            return null; // Will skip sending
          default:
            return value;
        }
      }
    }
    
    return value;
  }
}
```

### Protocol Adapters

```typescript
// simulator/adapters/mqtt.ts

export class MQTTAdapter implements ProtocolAdapter {
  private client: mqtt.MqttClient | null = null;
  
  async connect(config: ConnectionConfig) {
    this.client = mqtt.connect(config.brokerUrl, {
      username: config.username,
      password: config.password,
    });
    
    return new Promise<void>((resolve, reject) => {
      this.client!.on('connect', () => resolve());
      this.client!.on('error', (err) => reject(err));
    });
  }
  
  async sendBatch(messages: TelemetryMessage[]) {
    if (!this.client) throw new Error('Not connected');
    
    const promises = messages.map(msg => {
      const topic = `devices/${msg.deviceId}/telemetry`;
      const payload = JSON.stringify({ ts: msg.ts, values: msg.values });
      
      return new Promise<void>((resolve, reject) => {
        this.client!.publish(topic, payload, { qos: 1 }, (err) => {
          if (err) reject(err);
          else resolve();
        });
      });
    });
    
    await Promise.all(promises);
  }
  
  async disconnect() {
    if (this.client) {
      this.client.end();
      this.client = null;
    }
  }
}

// simulator/adapters/http.ts

export class HTTPAdapter implements ProtocolAdapter {
  private baseUrl: string = '';
  
  async connect(config: ConnectionConfig) {
    this.baseUrl = config.httpEndpoint;
  }
  
  async sendBatch(messages: TelemetryMessage[]) {
    const promises = messages.map(msg =>
      fetch(`${this.baseUrl}/api/webhook/telemetry`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${msg.accessToken}`,
        },
        body: JSON.stringify({ ts: msg.ts, values: msg.values }),
      })
    );
    
    await Promise.all(promises);
  }
  
  async disconnect() {
    // No persistent connection
  }
}
```

## 10.7 Simulator Web UI

```typescript
// simulator/web/pages/index.tsx

export default function SimulatorDashboard() {
  const [simulations, setSimulations] = useState<Simulation[]>([]);
  const [metrics, setMetrics] = useState<GlobalMetrics>({
    totalDevices: 0,
    messagesPerSecond: 0,
    bytesPerSecond: 0,
  });
  
  return (
    <div className="container mx-auto p-6">
      <header className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold">IoT Device Simulator</h1>
          <p className="text-muted-foreground">
            Generate realistic IoT telemetry for testing
          </p>
        </div>
        <div className="flex gap-2">
          <Button onClick={() => setShowNewDialog(true)}>
            <Plus className="h-4 w-4 mr-2" />
            New Simulation
          </Button>
          <Button variant="outline" onClick={handleImport}>
            <Upload className="h-4 w-4 mr-2" />
            Import
          </Button>
        </div>
      </header>
      
      {/* Global Metrics */}
      <div className="grid grid-cols-4 gap-4 mb-8">
        <MetricCard
          title="Total Devices"
          value={metrics.totalDevices}
          icon={Cpu}
        />
        <MetricCard
          title="Messages/sec"
          value={metrics.messagesPerSecond.toLocaleString()}
          icon={Activity}
        />
        <MetricCard
          title="Data Rate"
          value={formatBytes(metrics.bytesPerSecond) + '/s'}
          icon={ArrowUpDown}
        />
        <MetricCard
          title="Active Simulations"
          value={simulations.filter(s => s.status === 'running').length}
          icon={Play}
        />
      </div>
      
      {/* Simulation List */}
      <div className="space-y-4">
        {simulations.map(sim => (
          <SimulationCard
            key={sim.id}
            simulation={sim}
            onStart={() => sim.start()}
            onPause={() => sim.pause()}
            onStop={() => sim.stop()}
            onInjectAnomaly={(scenario) => sim.injectAnomaly(scenario)}
          />
        ))}
      </div>
      
      <NewSimulationDialog
        open={showNewDialog}
        onClose={() => setShowNewDialog(false)}
        onCreate={handleCreateSimulation}
      />
    </div>
  );
}
```
