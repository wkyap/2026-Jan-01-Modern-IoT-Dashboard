# 3. System Architecture

## 3.1 High-Level Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                                    CLIENTS                                           │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐                 │
│  │   Web App   │  │ Mobile Web  │  │  Admin UI   │  │  REST API   │                 │
│  │  (Next.js)  │  │ (Responsive)│  │             │  │  Consumers  │                 │
│  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘                 │
└─────────┴────────────────┴────────────────┴────────────────┴────────────────────────┘
                                    │
          ┌─────────────────────────┴─────────────────────────┐
          │              LOAD BALANCER (Traefik)               │
          └─────────────────────────┬─────────────────────────┘
                                    │
┌───────────────────────────────────┴─────────────────────────────────────────────────┐
│                              APPLICATION LAYER                                       │
│  ┌───────────────────────────────────────────────────────────────────────────────┐  │
│  │                     Next.js Application (App Router)                           │  │
│  │  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐              │  │
│  │  │  Dashboard  │ │   Device    │ │    User     │ │     AI      │              │  │
│  │  │   Module    │ │   Module    │ │   Module    │ │   Module    │              │  │
│  │  ├─────────────┤ ├─────────────┤ ├─────────────┤ ├─────────────┤              │  │
│  │  │   Alert     │ │    Rule     │ │   Tenant    │ │   Export    │              │  │
│  │  │   Module    │ │   Engine    │ │   Module    │ │   Module    │              │  │
│  │  └─────────────┘ └─────────────┘ └─────────────┘ └─────────────┘              │  │
│  └───────────────────────────────────────────────────────────────────────────────┘  │
│  ┌───────────────────────────────────────────────────────────────────────────────┐  │
│  │                    Real-Time Service (Socket.io Server)                        │  │
│  └───────────────────────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────────────────┘
                                    │
┌───────────────────────────────────┴─────────────────────────────────────────────────┐
│                              MESSAGE BROKER (Kafka/Redpanda)                         │
│  Topics: telemetry.{tenant}.raw | telemetry.{tenant}.processed | alerts.{tenant}    │
│          device.{tenant}.status | device.{tenant}.commands | ai.{tenant}.insights   │
└─────────────────────────────────────────────────────────────────────────────────────┘
                                    │
┌───────────────────────────────────┴─────────────────────────────────────────────────┐
│                              IoT PROTOCOL GATEWAY                                    │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐     │
│  │   MQTT   │ │   HTTP   │ │   CoAP   │ │  LwM2M   │ │  Modbus  │ │  OPC-UA  │     │
│  │  (EMQX)  │ │ Endpoint │ │ Gateway  │ │ (Leshan) │ │ Gateway  │ │ Adapter  │     │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘ └──────────┘ └──────────┘     │
└─────────────────────────────────────────────────────────────────────────────────────┘
                                    │
┌───────────────────────────────────┴─────────────────────────────────────────────────┐
│                              DATA PROCESSING (Benthos)                               │
│  Pipelines: Validation → Normalization → Aggregation → Anomaly Detection → Routing  │
└─────────────────────────────────────────────────────────────────────────────────────┘
                                    │
┌───────────────────────────────────┴─────────────────────────────────────────────────┐
│                              DATA STORAGE LAYER                                      │
│  ┌─────────────────────────┐  ┌─────────────────────────┐  ┌─────────────────────┐  │
│  │   PostgreSQL            │  │   TimescaleDB           │  │   Redis Cluster     │  │
│  │   (Per-Tenant DBs)      │  │   (Time-Series)         │  │   (Cache/Pub-Sub)   │  │
│  │   - Users, Roles        │  │   - Telemetry data      │  │   - Session cache   │  │
│  │   - Devices, Assets     │  │   - 1-min aggregates    │  │   - Real-time cache │  │
│  │   - Dashboards          │  │   - Continuous aggs     │  │   - Rate limiting   │  │
│  │   - Rules, Alerts       │  │   - 30-day retention    │  │   - Pub/Sub         │  │
│  └─────────────────────────┘  └─────────────────────────┘  └─────────────────────┘  │
│  ┌─────────────────────────┐  ┌─────────────────────────┐                           │
│  │   S3/MinIO              │  │   S3 Glacier            │                           │
│  │   (Object Storage)      │  │   (Cold Storage)        │                           │
│  │   - Exports, Reports    │  │   - 1-year retention    │                           │
│  └─────────────────────────┘  └─────────────────────────┘                           │
└─────────────────────────────────────────────────────────────────────────────────────┘
                                    │
┌───────────────────────────────────┴─────────────────────────────────────────────────┐
│                              AI / ML SERVICES                                        │
│  ┌─────────────────────────┐  ┌─────────────────────────┐                           │
│  │   Claude API (LLM)      │  │   Local Analysis        │                           │
│  │   - NL Dashboard Build  │  │   - Anomaly detection   │                           │
│  │   - NL Data Queries     │  │   - Forecasting         │                           │
│  │   - Alert Summaries     │  │   - Pattern matching    │                           │
│  └─────────────────────────┘  └─────────────────────────┘                           │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

## 3.2 Real-Time Data Flow

```
Device → Protocol Gateway → Kafka Topic → Benthos Pipeline → TimescaleDB
                                                         → Redis (cache)
                                                         → Rule Engine (alerts)
                                                         → Socket.io → Browser
```

## 3.3 Device Command Flow (RPC)

```
User Dashboard → API → Validate Permissions → Create Command Record → Audit Log
                                                         ↓
                                              Kafka: device.commands
                                                         ↓
                                              MQTT: devices/{id}/commands
                                                         ↓
                                                      Device
                                                         ↓
                                              MQTT: devices/{id}/response
                                                         ↓
                                              Update Command Status
                                                         ↓
                                              Socket.io → Dashboard (result)
```

## 3.4 API Architecture

```
/api/
├── auth/              (Auth.js handlers)
│   └── [...nextauth]  (OAuth callbacks)
├── trpc/[trpc]        (tRPC router - internal API)
├── v1/                (REST API - external/tenant API)
│   ├── devices        (CRUD + telemetry)
│   ├── telemetry      (Query + export)
│   ├── dashboards     (CRUD)
│   ├── alerts         (CRUD + acknowledge)
│   └── export         (Bulk export)
├── realtime/          (Socket.io upgrade)
├── ai/                (AI endpoints)
│   ├── query          (Natural language query)
│   ├── dashboard      (Generate dashboard)
│   └── insights       (Get insights)
└── webhook/           (External webhooks)
    └── telemetry      (HTTP device ingestion)
```
