# 7. Widget System

## 7.1 Widget Type Registry

| Category | Widget Type | Description | Data Source |
|----------|------------|-------------|-------------|
| **Charts** | `line_chart` | Time-series line chart | timeseries |
| | `area_chart` | Filled area chart | timeseries |
| | `bar_chart` | Vertical/horizontal bars | timeseries, latest |
| | `pie_chart` | Pie/donut chart | latest |
| **Values** | `gauge` | Radial gauge with thresholds | latest |
| | `value_card` | Single value display | latest |
| | `led_indicator` | On/off status indicator | latest |
| | `stats_card` | Value with trend indicator | latest |
| **Tables** | `alarm_table` | Alert list with actions | alerts |
| | `device_table` | Device list with status | devices |
| | `telemetry_table` | Raw telemetry data table | timeseries |
| **Controls** | `control_button` | Command trigger button | n/a |
| | `control_slider` | Value slider control | n/a |
| | `control_switch` | On/off toggle | n/a |
| **Maps** | `device_map` | Device location map | devices |
| | `heatmap` | Value density map | latest |
| **Static** | `html` | Custom HTML content | static |
| | `markdown` | Markdown content | static |
| | `image` | Image display | static |
| **AI** | `ai_insight` | AI-generated insights | ai |
| | `anomaly_chart` | Anomaly-highlighted chart | timeseries |

## 7.2 Widget Type Definitions

```typescript
// types/widget.ts

export type WidgetType =
  // Charts
  | 'line_chart'
  | 'area_chart'
  | 'bar_chart'
  | 'pie_chart'
  // Values
  | 'gauge'
  | 'value_card'
  | 'led_indicator'
  | 'stats_card'
  // Tables
  | 'alarm_table'
  | 'device_table'
  | 'telemetry_table'
  // Controls
  | 'control_button'
  | 'control_slider'
  | 'control_switch'
  // Maps
  | 'device_map'
  | 'heatmap'
  // Static
  | 'html'
  | 'markdown'
  | 'image'
  // AI
  | 'ai_insight'
  | 'anomaly_chart';

export interface Widget {
  id: string;
  type: WidgetType;
  title: string;
  position: WidgetPosition;
  dataSource: DataSourceConfig;
  config: WidgetConfig;
  style?: WidgetStyle;
}

export interface WidgetPosition {
  x: number;      // Grid column (0-11)
  y: number;      // Grid row
  w: number;      // Width in columns (1-12)
  h: number;      // Height in rows
}

export interface DataSourceConfig {
  type: 'timeseries' | 'latest' | 'alerts' | 'devices' | 'static' | 'ai';
  
  // For telemetry data
  deviceIds?: string[];
  deviceProfileId?: string;
  keys?: string[];
  
  // Time range
  timeRange?: TimeRange;
  
  // Aggregation
  aggregation?: 'none' | 'avg' | 'min' | 'max' | 'sum' | 'count';
  interval?: '1m' | '5m' | '15m' | '1h' | '1d';
  
  // For static content
  content?: string;
}

export type TimeRange =
  | { type: 'relative'; value: string }  // '15m', '1h', '24h', '7d', '30d'
  | { type: 'absolute'; start: string; end: string };
```

## 7.3 Widget Configurations

### Line/Area Chart Config
```typescript
interface ChartConfig {
  chartType: 'line' | 'area' | 'bar';
  showLegend: boolean;
  showGrid: boolean;
  showTooltip: boolean;
  yAxisMin?: number;
  yAxisMax?: number;
  yAxisLabel?: string;
  xAxisLabel?: string;
  colors?: string[];
  stacked?: boolean;
  smooth?: boolean;
}
```

### Gauge Config
```typescript
interface GaugeConfig {
  min: number;
  max: number;
  unit: string;
  decimals: number;
  thresholds: {
    value: number;
    color: string;
    label?: string;
  }[];
  showMinMax: boolean;
  arcWidth: number;
}
```

### Value Card Config
```typescript
interface ValueCardConfig {
  unit: string;
  decimals: number;
  fontSize: 'small' | 'medium' | 'large';
  showTrend: boolean;
  trendPeriod: string;
  colorRules?: {
    condition: 'gt' | 'lt' | 'eq';
    value: number;
    color: string;
  }[];
}
```

### Alarm Table Config
```typescript
interface AlarmTableConfig {
  columns: ('severity' | 'device' | 'message' | 'time' | 'status' | 'actions')[];
  pageSize: number;
  showFilters: boolean;
  defaultSeverityFilter?: string[];
  defaultStatusFilter?: string[];
}
```

### Control Button Config
```typescript
interface ControlButtonConfig {
  commandType: string;
  commandParams: Record<string, any>;
  label: string;
  confirmRequired: boolean;
  confirmMessage?: string;
  variant: 'default' | 'primary' | 'danger';
  icon?: string;
}
```

### Map Config
```typescript
interface MapConfig {
  mapStyle: 'streets' | 'satellite' | 'dark' | 'light';
  defaultZoom: number;
  defaultCenter: [number, number];
  clusterDevices: boolean;
  showStatusColors: boolean;
  popupFields: string[];
}
```

## 7.4 Widget Component Pattern

```typescript
// components/widgets/base/widget-wrapper.tsx

interface WidgetWrapperProps {
  widget: Widget;
  isEditing: boolean;
  isSelected: boolean;
  onSelect: () => void;
  onUpdate: (updates: Partial<Widget>) => void;
  children: React.ReactNode;
}

export function WidgetWrapper({
  widget,
  isEditing,
  isSelected,
  onSelect,
  onUpdate,
  children
}: WidgetWrapperProps) {
  return (
    <Card
      className={cn(
        'h-full flex flex-col overflow-hidden',
        isEditing && 'cursor-move hover:ring-2 hover:ring-primary/50',
        isSelected && 'ring-2 ring-primary'
      )}
      onClick={isEditing ? onSelect : undefined}
    >
      <WidgetHeader
        title={widget.title}
        isEditing={isEditing}
        onTitleChange={(title) => onUpdate({ title })}
        onRefresh={() => {/* trigger data refresh */}}
        onSettings={() => {/* open settings panel */}}
      />
      <CardContent className="flex-1 p-4 overflow-hidden">
        <ErrorBoundary fallback={<WidgetError />}>
          <Suspense fallback={<WidgetLoading />}>
            {children}
          </Suspense>
        </ErrorBoundary>
      </CardContent>
    </Card>
  );
}
```

## 7.5 Widget Data Hook

```typescript
// hooks/useWidgetData.ts

export function useWidgetData(dataSource: DataSourceConfig) {
  const queryClient = useQueryClient();
  const { socket } = useSocket();
  
  const queryKey = useMemo(() => ['widget-data', dataSource], [dataSource]);
  
  // Fetch initial/historical data
  const query = useQuery({
    queryKey,
    queryFn: () => fetchWidgetData(dataSource),
    staleTime: dataSource.type === 'latest' ? 0 : 60000,
    refetchInterval: dataSource.type === 'latest' ? 5000 : false,
  });
  
  // Subscribe to real-time updates
  useEffect(() => {
    if (!socket || !['timeseries', 'latest'].includes(dataSource.type)) {
      return;
    }
    
    const deviceIds = dataSource.deviceIds || [];
    const keys = dataSource.keys || [];
    
    deviceIds.forEach(deviceId => {
      socket.emit('subscribe:telemetry', { deviceId, keys });
    });
    
    const handleTelemetry = (payload: TelemetryUpdate) => {
      queryClient.setQueryData(queryKey, (old: any) => {
        return mergeTelemetryData(old, payload);
      });
    };
    
    socket.on('telemetry:update', handleTelemetry);
    
    return () => {
      deviceIds.forEach(deviceId => {
        socket.emit('unsubscribe:telemetry', { deviceId });
      });
      socket.off('telemetry:update', handleTelemetry);
    };
  }, [dataSource, socket, queryClient, queryKey]);
  
  return query;
}
```

## 7.6 Widget Registry

```typescript
// lib/widgets/registry.ts

export interface WidgetDefinition {
  type: WidgetType;
  name: string;
  description: string;
  icon: LucideIcon;
  category: WidgetCategory;
  component: React.ComponentType<WidgetProps>;
  configComponent: React.ComponentType<WidgetConfigProps>;
  defaultConfig: Partial<WidgetConfig>;
  defaultSize: { w: number; h: number };
  minSize: { w: number; h: number };
  maxSize: { w: number; h: number };
  dataSourceTypes: DataSourceConfig['type'][];
}

export const WIDGET_REGISTRY: Record<WidgetType, WidgetDefinition> = {
  line_chart: {
    type: 'line_chart',
    name: 'Line Chart',
    description: 'Display time-series data as a line chart',
    icon: LineChart,
    category: 'charts',
    component: LineChartWidget,
    configComponent: LineChartConfig,
    defaultConfig: { showLegend: true, showGrid: true },
    defaultSize: { w: 6, h: 3 },
    minSize: { w: 3, h: 2 },
    maxSize: { w: 12, h: 6 },
    dataSourceTypes: ['timeseries'],
  },
  gauge: {
    type: 'gauge',
    name: 'Gauge',
    description: 'Display a single value as a radial gauge',
    icon: Gauge,
    category: 'values',
    component: GaugeWidget,
    configComponent: GaugeConfig,
    defaultConfig: { min: 0, max: 100, decimals: 1 },
    defaultSize: { w: 2, h: 2 },
    minSize: { w: 2, h: 2 },
    maxSize: { w: 4, h: 4 },
    dataSourceTypes: ['latest'],
  },
  // ... other widgets
};

export const WIDGET_CATEGORIES = {
  charts: { name: 'Charts', icon: BarChart3 },
  values: { name: 'Values', icon: Activity },
  tables: { name: 'Tables', icon: Table },
  controls: { name: 'Controls', icon: Sliders },
  maps: { name: 'Maps', icon: Map },
  static: { name: 'Static', icon: FileText },
  ai: { name: 'AI', icon: Sparkles },
};
```

---

# 8. Dashboard Builder

## 8.1 Builder UI Layout

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│  Dashboard Builder                                              [Preview] [Save]    │
├────────────┬────────────────────────────────────────────────────────────────────────┤
│            │                                                                        │
│  WIDGETS   │                        CANVAS                                          │
│            │  ┌──────────────────────────────────────────────────────────────────┐  │
│  ○ Charts  │  │                                                                  │  │
│    Line    │  │    ┌────────────┐  ┌────────────┐  ┌────────────┐               │  │
│    Area    │  │    │   Widget   │  │   Widget   │  │   Widget   │               │  │
│    Bar     │  │    │     1      │  │     2      │  │     3      │               │  │
│            │  │    └────────────┘  └────────────┘  └────────────┘               │  │
│  ○ Values  │  │                                                                  │  │
│    Gauge   │  │    ┌─────────────────────────────────────────────┐               │  │
│    Card    │  │    │                Widget 4                      │               │  │
│            │  │    │                                              │               │  │
│  ○ Tables  │  │    └─────────────────────────────────────────────┘               │  │
│            │  │                                                                  │  │
│  ○ Controls│  └──────────────────────────────────────────────────────────────────┘  │
│            │                                                                        │
│  ○ Maps    ├────────────────────────────────────────────────────────────────────────┤
│            │                     PROPERTIES PANEL                                   │
│  ○ Static  │  ┌──────────────────────────────────────────────────────────────────┐  │
│            │  │  Widget: Line Chart                                              │  │
│  ○ AI      │  │  ─────────────────────────────────────────────────────────────   │  │
│            │  │                                                                  │  │
│ ───────────│  │  📊 Data Source                                                  │  │
│            │  │  Device: [Select devices...                    ▼]               │  │
│  🤖 AI     │  │  Keys:   [temperature, humidity               ▼]               │  │
│  Assistant │  │  Time:   [Last 24 hours                       ▼]               │  │
│            │  │  Agg:    [5 minute average                    ▼]               │  │
│  "Create a │  │                                                                  │  │
│   dashboard│  │  🎨 Appearance                                                   │  │
│   for..."  │  │  Title: [Temperature Trend                     ]               │  │
│            │  │  Legend: ☑ Show                                                 │  │
│  [Send]    │  │  Grid:   ☑ Show                                                 │  │
│            │  │                                                                  │  │
│            │  │  [🤖 AI: Suggest optimal config]                                │  │
│            │  └──────────────────────────────────────────────────────────────────┘  │
└────────────┴────────────────────────────────────────────────────────────────────────┘
```

## 8.2 Builder State Management

```typescript
// stores/useDashboardStore.ts

interface DashboardBuilderState {
  // Dashboard data
  dashboard: Dashboard | null;
  widgets: Widget[];
  
  // Edit state
  isEditing: boolean;
  isDirty: boolean;
  
  // Selection
  selectedWidgetId: string | null;
  
  // Clipboard
  copiedWidget: Widget | null;
  
  // History (undo/redo)
  history: HistoryEntry[];
  historyIndex: number;
  
  // Actions
  setDashboard: (dashboard: Dashboard) => void;
  addWidget: (widget: Omit<Widget, 'id'>) => void;
  updateWidget: (id: string, updates: Partial<Widget>) => void;
  removeWidget: (id: string) => void;
  moveWidget: (id: string, position: WidgetPosition) => void;
  resizeWidget: (id: string, size: { w: number; h: number }) => void;
  selectWidget: (id: string | null) => void;
  copyWidget: (id: string) => void;
  pasteWidget: () => void;
  undo: () => void;
  redo: () => void;
  save: () => Promise<void>;
}

export const useDashboardStore = create<DashboardBuilderState>()(
  devtools(
    immer((set, get) => ({
      dashboard: null,
      widgets: [],
      isEditing: false,
      isDirty: false,
      selectedWidgetId: null,
      copiedWidget: null,
      history: [],
      historyIndex: -1,
      
      addWidget: (widget) => {
        const newWidget = { ...widget, id: generateId() };
        set((state) => {
          state.widgets.push(newWidget);
          state.isDirty = true;
          state.selectedWidgetId = newWidget.id;
          pushHistory(state);
        });
      },
      
      updateWidget: (id, updates) => {
        set((state) => {
          const index = state.widgets.findIndex(w => w.id === id);
          if (index !== -1) {
            state.widgets[index] = { ...state.widgets[index], ...updates };
            state.isDirty = true;
            pushHistory(state);
          }
        });
      },
      
      // ... other actions
    }))
  )
);
```

## 8.3 Grid Layout System

```typescript
// components/builder/dashboard-canvas.tsx

import { DndContext, DragOverlay } from '@dnd-kit/core';
import { restrictToParentElement } from '@dnd-kit/modifiers';

interface DashboardCanvasProps {
  widgets: Widget[];
  isEditing: boolean;
  onWidgetMove: (id: string, position: WidgetPosition) => void;
  onWidgetResize: (id: string, size: { w: number; h: number }) => void;
}

export function DashboardCanvas({
  widgets,
  isEditing,
  onWidgetMove,
  onWidgetResize,
}: DashboardCanvasProps) {
  const [activeId, setActiveId] = useState<string | null>(null);
  const gridRef = useRef<HTMLDivElement>(null);
  
  const GRID_COLS = 12;
  const ROW_HEIGHT = 80;
  const GAP = 16;
  
  const handleDragEnd = (event: DragEndEvent) => {
    const { active, delta } = event;
    if (!gridRef.current) return;
    
    const widget = widgets.find(w => w.id === active.id);
    if (!widget) return;
    
    const gridRect = gridRef.current.getBoundingClientRect();
    const colWidth = (gridRect.width - GAP * (GRID_COLS - 1)) / GRID_COLS;
    
    const newX = Math.round((widget.position.x * colWidth + delta.x) / colWidth);
    const newY = Math.round((widget.position.y * ROW_HEIGHT + delta.y) / ROW_HEIGHT);
    
    onWidgetMove(widget.id, {
      ...widget.position,
      x: Math.max(0, Math.min(GRID_COLS - widget.position.w, newX)),
      y: Math.max(0, newY),
    });
    
    setActiveId(null);
  };
  
  return (
    <DndContext
      modifiers={[restrictToParentElement]}
      onDragStart={({ active }) => setActiveId(active.id as string)}
      onDragEnd={handleDragEnd}
    >
      <div
        ref={gridRef}
        className="relative min-h-[600px] bg-muted/30 rounded-lg p-4"
        style={{
          backgroundImage: isEditing
            ? `repeating-linear-gradient(
                0deg,
                transparent,
                transparent ${ROW_HEIGHT - 1}px,
                hsl(var(--border)) ${ROW_HEIGHT - 1}px,
                hsl(var(--border)) ${ROW_HEIGHT}px
              )`
            : 'none',
        }}
      >
        {widgets.map((widget) => (
          <WidgetContainer
            key={widget.id}
            widget={widget}
            isEditing={isEditing}
            gridCols={GRID_COLS}
            rowHeight={ROW_HEIGHT}
            gap={GAP}
            onResize={(size) => onWidgetResize(widget.id, size)}
          />
        ))}
      </div>
      
      <DragOverlay>
        {activeId && (
          <WidgetDragPreview
            widget={widgets.find(w => w.id === activeId)!}
          />
        )}
      </DragOverlay>
    </DndContext>
  );
}
```

## 8.4 Widget Palette

```typescript
// components/builder/widget-palette.tsx

export function WidgetPalette() {
  const { addWidget } = useDashboardStore();
  
  return (
    <div className="space-y-4">
      {Object.entries(WIDGET_CATEGORIES).map(([key, category]) => (
        <Collapsible key={key} defaultOpen>
          <CollapsibleTrigger className="flex items-center gap-2 w-full p-2 hover:bg-muted rounded-md">
            <category.icon className="h-4 w-4" />
            <span className="font-medium">{category.name}</span>
            <ChevronDown className="h-4 w-4 ml-auto" />
          </CollapsibleTrigger>
          <CollapsibleContent className="pl-6 space-y-1">
            {Object.values(WIDGET_REGISTRY)
              .filter(w => w.category === key)
              .map((widget) => (
                <button
                  key={widget.type}
                  className="flex items-center gap-2 w-full p-2 text-sm hover:bg-muted rounded-md"
                  onClick={() => addWidget({
                    type: widget.type,
                    title: widget.name,
                    position: findEmptyPosition(widget.defaultSize),
                    dataSource: { type: widget.dataSourceTypes[0] },
                    config: widget.defaultConfig,
                  })}
                >
                  <widget.icon className="h-4 w-4" />
                  <span>{widget.name}</span>
                </button>
              ))}
          </CollapsibleContent>
        </Collapsible>
      ))}
    </div>
  );
}
```

## 8.5 Property Panel

```typescript
// components/builder/property-panel.tsx

export function PropertyPanel() {
  const { selectedWidgetId, widgets, updateWidget } = useDashboardStore();
  
  const widget = widgets.find(w => w.id === selectedWidgetId);
  
  if (!widget) {
    return (
      <div className="p-4 text-center text-muted-foreground">
        Select a widget to edit its properties
      </div>
    );
  }
  
  const definition = WIDGET_REGISTRY[widget.type];
  const ConfigComponent = definition.configComponent;
  
  return (
    <ScrollArea className="h-full">
      <div className="p-4 space-y-6">
        {/* Title */}
        <div className="space-y-2">
          <Label>Title</Label>
          <Input
            value={widget.title}
            onChange={(e) => updateWidget(widget.id, { title: e.target.value })}
          />
        </div>
        
        {/* Data Source */}
        <DataSourceConfig
          dataSource={widget.dataSource}
          allowedTypes={definition.dataSourceTypes}
          onChange={(dataSource) => updateWidget(widget.id, { dataSource })}
        />
        
        {/* Widget-specific config */}
        <ConfigComponent
          config={widget.config}
          onChange={(config) => updateWidget(widget.id, { config })}
        />
        
        {/* AI Suggestions */}
        <div className="pt-4 border-t">
          <Button
            variant="outline"
            className="w-full"
            onClick={() => getAISuggestions(widget)}
          >
            <Sparkles className="h-4 w-4 mr-2" />
            AI: Suggest optimal config
          </Button>
        </div>
      </div>
    </ScrollArea>
  );
}
```
