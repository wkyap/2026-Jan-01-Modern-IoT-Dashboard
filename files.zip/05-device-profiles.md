# 6. Device Profiles (Industrial Standard Templates)

## 6.1 Profile Categories

| Category | Description | Example Devices |
|----------|-------------|-----------------|
| Industrial | Manufacturing and factory equipment | Motors, sensors, PLCs |
| Building | Building automation systems | HVAC, lighting, occupancy |
| Environmental | Weather and environmental monitoring | Weather stations, air quality |
| Fleet | Vehicle and transportation | GPS trackers, OBD readers |
| Energy | Power and energy management | Meters, inverters, batteries |
| Agriculture | Farming and agriculture | Soil sensors, irrigation |
| Infrastructure | Network and system devices | Gateways, edge devices |

## 6.2 Industrial Device Profiles

### Temperature Sensor
```json
{
  "name": "Temperature Sensor",
  "type": "sensor",
  "category": "industrial",
  "telemetryKeys": [
    { "key": "temperature", "type": "number", "unit": "°C", "min": -40, "max": 125 },
    { "key": "battery", "type": "number", "unit": "%", "min": 0, "max": 100 }
  ],
  "attributeKeys": [
    { "key": "firmware_version", "type": "string" },
    { "key": "calibration_date", "type": "date" },
    { "key": "accuracy", "type": "string" },
    { "key": "location", "type": "string" }
  ],
  "commandTypes": [
    { "name": "reboot", "params": [] },
    { "name": "set_interval", "params": [{ "name": "interval_ms", "type": "number" }] },
    { "name": "calibrate", "params": [] }
  ],
  "defaultAlertRules": [
    { "key": "temperature", "condition": "gt", "threshold": 40, "severity": "warning" },
    { "key": "temperature", "condition": "gt", "threshold": 50, "severity": "critical" },
    { "key": "battery", "condition": "lt", "threshold": 20, "severity": "warning" }
  ],
  "icon": "thermometer"
}
```

### Humidity Sensor
```json
{
  "name": "Humidity Sensor",
  "type": "sensor",
  "category": "industrial",
  "telemetryKeys": [
    { "key": "humidity", "type": "number", "unit": "%", "min": 0, "max": 100 },
    { "key": "temperature", "type": "number", "unit": "°C", "min": -40, "max": 85 },
    { "key": "battery", "type": "number", "unit": "%", "min": 0, "max": 100 }
  ],
  "attributeKeys": [
    { "key": "firmware_version", "type": "string" },
    { "key": "location", "type": "string" }
  ],
  "commandTypes": [
    { "name": "reboot", "params": [] },
    { "name": "set_interval", "params": [{ "name": "interval_ms", "type": "number" }] }
  ],
  "defaultAlertRules": [
    { "key": "humidity", "condition": "gt", "threshold": 80, "severity": "warning" },
    { "key": "humidity", "condition": "lt", "threshold": 20, "severity": "warning" }
  ],
  "icon": "droplets"
}
```

### Pressure Sensor
```json
{
  "name": "Pressure Sensor",
  "type": "sensor",
  "category": "industrial",
  "telemetryKeys": [
    { "key": "pressure", "type": "number", "unit": "bar", "min": 0, "max": 100 },
    { "key": "temperature", "type": "number", "unit": "°C" }
  ],
  "attributeKeys": [
    { "key": "firmware_version", "type": "string" },
    { "key": "max_pressure", "type": "number" },
    { "key": "location", "type": "string" }
  ],
  "commandTypes": [
    { "name": "calibrate", "params": [] },
    { "name": "reboot", "params": [] }
  ],
  "defaultAlertRules": [
    { "key": "pressure", "condition": "gt", "threshold": 80, "severity": "critical" }
  ],
  "icon": "gauge"
}
```

### Flow Meter
```json
{
  "name": "Flow Meter",
  "type": "sensor",
  "category": "industrial",
  "telemetryKeys": [
    { "key": "flow_rate", "type": "number", "unit": "L/min", "min": 0 },
    { "key": "total_volume", "type": "number", "unit": "L", "min": 0 },
    { "key": "temperature", "type": "number", "unit": "°C" }
  ],
  "attributeKeys": [
    { "key": "pipe_diameter", "type": "number" },
    { "key": "max_flow", "type": "number" },
    { "key": "location", "type": "string" }
  ],
  "commandTypes": [
    { "name": "reset_counter", "params": [] },
    { "name": "reboot", "params": [] }
  ],
  "icon": "waves"
}
```

### Industrial Motor
```json
{
  "name": "Industrial Motor",
  "type": "actuator",
  "category": "industrial",
  "telemetryKeys": [
    { "key": "rpm", "type": "number", "unit": "RPM", "min": 0, "max": 5000 },
    { "key": "current", "type": "number", "unit": "A", "min": 0 },
    { "key": "temperature", "type": "number", "unit": "°C" },
    { "key": "vibration", "type": "number", "unit": "mm/s" },
    { "key": "power", "type": "number", "unit": "kW" },
    { "key": "running", "type": "boolean" }
  ],
  "attributeKeys": [
    { "key": "model", "type": "string" },
    { "key": "power_rating", "type": "number" },
    { "key": "max_rpm", "type": "number" },
    { "key": "location", "type": "string" }
  ],
  "commandTypes": [
    { "name": "start", "params": [] },
    { "name": "stop", "params": [] },
    { "name": "set_speed", "params": [{ "name": "rpm", "type": "number" }] },
    { "name": "emergency_stop", "params": [] }
  ],
  "defaultAlertRules": [
    { "key": "temperature", "condition": "gt", "threshold": 80, "severity": "warning" },
    { "key": "temperature", "condition": "gt", "threshold": 95, "severity": "critical" },
    { "key": "vibration", "condition": "gt", "threshold": 10, "severity": "warning" }
  ],
  "icon": "cog"
}
```

### Power Meter
```json
{
  "name": "Power Meter",
  "type": "sensor",
  "category": "energy",
  "telemetryKeys": [
    { "key": "voltage", "type": "number", "unit": "V" },
    { "key": "current", "type": "number", "unit": "A" },
    { "key": "power", "type": "number", "unit": "kW" },
    { "key": "energy", "type": "number", "unit": "kWh" },
    { "key": "power_factor", "type": "number", "unit": "" },
    { "key": "frequency", "type": "number", "unit": "Hz" }
  ],
  "attributeKeys": [
    { "key": "phase", "type": "string" },
    { "key": "max_current", "type": "number" },
    { "key": "ct_ratio", "type": "string" },
    { "key": "location", "type": "string" }
  ],
  "commandTypes": [
    { "name": "reset_energy", "params": [] },
    { "name": "reboot", "params": [] }
  ],
  "icon": "zap"
}
```

## 6.3 Building Automation Profiles

### HVAC Unit
```json
{
  "name": "HVAC Unit",
  "type": "controller",
  "category": "building",
  "telemetryKeys": [
    { "key": "supply_temp", "type": "number", "unit": "°C" },
    { "key": "return_temp", "type": "number", "unit": "°C" },
    { "key": "setpoint", "type": "number", "unit": "°C" },
    { "key": "fan_speed", "type": "number", "unit": "%" },
    { "key": "mode", "type": "string" },
    { "key": "power", "type": "number", "unit": "kW" }
  ],
  "attributeKeys": [
    { "key": "zone", "type": "string" },
    { "key": "capacity", "type": "number" },
    { "key": "model", "type": "string" }
  ],
  "commandTypes": [
    { "name": "set_mode", "params": [{ "name": "mode", "type": "string", "enum": ["cooling", "heating", "auto", "off"] }] },
    { "name": "set_setpoint", "params": [{ "name": "temperature", "type": "number" }] },
    { "name": "set_fan_speed", "params": [{ "name": "speed", "type": "number" }] }
  ],
  "icon": "wind"
}
```

### Occupancy Sensor
```json
{
  "name": "Occupancy Sensor",
  "type": "sensor",
  "category": "building",
  "telemetryKeys": [
    { "key": "occupied", "type": "boolean" },
    { "key": "count", "type": "number", "unit": "people" },
    { "key": "battery", "type": "number", "unit": "%" }
  ],
  "attributeKeys": [
    { "key": "zone", "type": "string" },
    { "key": "max_capacity", "type": "number" },
    { "key": "detection_range", "type": "number" }
  ],
  "commandTypes": [
    { "name": "reset_count", "params": [] }
  ],
  "icon": "users"
}
```

### Air Quality Sensor
```json
{
  "name": "Air Quality Sensor",
  "type": "sensor",
  "category": "building",
  "telemetryKeys": [
    { "key": "co2", "type": "number", "unit": "ppm" },
    { "key": "pm25", "type": "number", "unit": "µg/m³" },
    { "key": "pm10", "type": "number", "unit": "µg/m³" },
    { "key": "voc", "type": "number", "unit": "ppb" },
    { "key": "temperature", "type": "number", "unit": "°C" },
    { "key": "humidity", "type": "number", "unit": "%" }
  ],
  "attributeKeys": [
    { "key": "location", "type": "string" },
    { "key": "firmware_version", "type": "string" }
  ],
  "commandTypes": [
    { "name": "calibrate", "params": [] }
  ],
  "defaultAlertRules": [
    { "key": "co2", "condition": "gt", "threshold": 1000, "severity": "warning" },
    { "key": "pm25", "condition": "gt", "threshold": 35, "severity": "warning" }
  ],
  "icon": "cloud"
}
```

### Lighting Controller
```json
{
  "name": "Lighting Controller",
  "type": "actuator",
  "category": "building",
  "telemetryKeys": [
    { "key": "brightness", "type": "number", "unit": "%" },
    { "key": "power", "type": "number", "unit": "W" },
    { "key": "on", "type": "boolean" },
    { "key": "color_temp", "type": "number", "unit": "K" }
  ],
  "attributeKeys": [
    { "key": "zone", "type": "string" },
    { "key": "fixture_count", "type": "number" },
    { "key": "max_power", "type": "number" }
  ],
  "commandTypes": [
    { "name": "turn_on", "params": [] },
    { "name": "turn_off", "params": [] },
    { "name": "set_brightness", "params": [{ "name": "level", "type": "number" }] },
    { "name": "set_color_temp", "params": [{ "name": "kelvin", "type": "number" }] }
  ],
  "icon": "lightbulb"
}
```

## 6.4 Fleet/Vehicle Profiles

### Vehicle GPS Tracker
```json
{
  "name": "Vehicle GPS Tracker",
  "type": "sensor",
  "category": "fleet",
  "telemetryKeys": [
    { "key": "latitude", "type": "number", "unit": "°" },
    { "key": "longitude", "type": "number", "unit": "°" },
    { "key": "speed", "type": "number", "unit": "km/h" },
    { "key": "heading", "type": "number", "unit": "°" },
    { "key": "altitude", "type": "number", "unit": "m" },
    { "key": "satellites", "type": "number" },
    { "key": "battery", "type": "number", "unit": "%" }
  ],
  "attributeKeys": [
    { "key": "vehicle_id", "type": "string" },
    { "key": "plate_number", "type": "string" },
    { "key": "driver", "type": "string" },
    { "key": "imei", "type": "string" }
  ],
  "commandTypes": [
    { "name": "get_location", "params": [] },
    { "name": "set_interval", "params": [{ "name": "seconds", "type": "number" }] }
  ],
  "icon": "map-pin"
}
```

### Vehicle Diagnostics (OBD)
```json
{
  "name": "Vehicle Diagnostics (OBD)",
  "type": "sensor",
  "category": "fleet",
  "telemetryKeys": [
    { "key": "engine_rpm", "type": "number", "unit": "RPM" },
    { "key": "vehicle_speed", "type": "number", "unit": "km/h" },
    { "key": "fuel_level", "type": "number", "unit": "%" },
    { "key": "engine_temp", "type": "number", "unit": "°C" },
    { "key": "battery_voltage", "type": "number", "unit": "V" },
    { "key": "odometer", "type": "number", "unit": "km" },
    { "key": "dtc_count", "type": "number" }
  ],
  "attributeKeys": [
    { "key": "vin", "type": "string" },
    { "key": "make", "type": "string" },
    { "key": "model", "type": "string" },
    { "key": "year", "type": "number" }
  ],
  "commandTypes": [
    { "name": "read_dtc", "params": [] },
    { "name": "clear_dtc", "params": [] }
  ],
  "defaultAlertRules": [
    { "key": "engine_temp", "condition": "gt", "threshold": 100, "severity": "warning" },
    { "key": "battery_voltage", "condition": "lt", "threshold": 11.5, "severity": "warning" }
  ],
  "icon": "car"
}
```

## 6.5 Environmental Profiles

### Weather Station
```json
{
  "name": "Weather Station",
  "type": "sensor",
  "category": "environmental",
  "telemetryKeys": [
    { "key": "temperature", "type": "number", "unit": "°C" },
    { "key": "humidity", "type": "number", "unit": "%" },
    { "key": "pressure", "type": "number", "unit": "hPa" },
    { "key": "wind_speed", "type": "number", "unit": "m/s" },
    { "key": "wind_direction", "type": "number", "unit": "°" },
    { "key": "rainfall", "type": "number", "unit": "mm" },
    { "key": "uv_index", "type": "number" },
    { "key": "solar_radiation", "type": "number", "unit": "W/m²" }
  ],
  "attributeKeys": [
    { "key": "location", "type": "string" },
    { "key": "altitude", "type": "number" },
    { "key": "station_id", "type": "string" }
  ],
  "commandTypes": [],
  "icon": "cloud-sun"
}
```

### Soil Sensor
```json
{
  "name": "Soil Sensor",
  "type": "sensor",
  "category": "agriculture",
  "telemetryKeys": [
    { "key": "soil_moisture", "type": "number", "unit": "%" },
    { "key": "soil_temp", "type": "number", "unit": "°C" },
    { "key": "ph", "type": "number" },
    { "key": "ec", "type": "number", "unit": "dS/m" },
    { "key": "nitrogen", "type": "number", "unit": "mg/kg" },
    { "key": "phosphorus", "type": "number", "unit": "mg/kg" },
    { "key": "potassium", "type": "number", "unit": "mg/kg" }
  ],
  "attributeKeys": [
    { "key": "plot", "type": "string" },
    { "key": "depth", "type": "number" },
    { "key": "crop_type", "type": "string" }
  ],
  "commandTypes": [],
  "defaultAlertRules": [
    { "key": "soil_moisture", "condition": "lt", "threshold": 20, "severity": "warning" }
  ],
  "icon": "sprout"
}
```

## 6.6 Infrastructure Profiles

### IoT Gateway
```json
{
  "name": "IoT Gateway",
  "type": "gateway",
  "category": "infrastructure",
  "isGateway": true,
  "telemetryKeys": [
    { "key": "cpu_usage", "type": "number", "unit": "%" },
    { "key": "memory_usage", "type": "number", "unit": "%" },
    { "key": "disk_usage", "type": "number", "unit": "%" },
    { "key": "connected_devices", "type": "number" },
    { "key": "uptime", "type": "number", "unit": "seconds" },
    { "key": "messages_sent", "type": "number" },
    { "key": "messages_received", "type": "number" }
  ],
  "attributeKeys": [
    { "key": "firmware_version", "type": "string" },
    { "key": "ip_address", "type": "string" },
    { "key": "mac_address", "type": "string" },
    { "key": "model", "type": "string" }
  ],
  "commandTypes": [
    { "name": "reboot", "params": [] },
    { "name": "update_firmware", "params": [{ "name": "url", "type": "string" }] },
    { "name": "scan_devices", "params": [] },
    { "name": "restart_service", "params": [{ "name": "service", "type": "string" }] }
  ],
  "defaultAlertRules": [
    { "key": "cpu_usage", "condition": "gt", "threshold": 90, "severity": "warning" },
    { "key": "memory_usage", "condition": "gt", "threshold": 90, "severity": "warning" },
    { "key": "disk_usage", "condition": "gt", "threshold": 85, "severity": "warning" }
  ],
  "icon": "router"
}
```

### Network Switch
```json
{
  "name": "Network Switch",
  "type": "sensor",
  "category": "infrastructure",
  "telemetryKeys": [
    { "key": "port_status", "type": "json" },
    { "key": "cpu_usage", "type": "number", "unit": "%" },
    { "key": "temperature", "type": "number", "unit": "°C" },
    { "key": "uptime", "type": "number", "unit": "seconds" },
    { "key": "throughput_in", "type": "number", "unit": "Mbps" },
    { "key": "throughput_out", "type": "number", "unit": "Mbps" }
  ],
  "attributeKeys": [
    { "key": "model", "type": "string" },
    { "key": "firmware", "type": "string" },
    { "key": "ip_address", "type": "string" },
    { "key": "port_count", "type": "number" }
  ],
  "commandTypes": [
    { "name": "reboot", "params": [] }
  ],
  "icon": "network"
}
```
