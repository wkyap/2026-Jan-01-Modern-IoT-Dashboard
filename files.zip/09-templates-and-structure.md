# 11. Dashboard Templates

## 11.1 Template Categories

| Category | Use Case | Templates |
|----------|----------|-----------|
| Industrial | Manufacturing, factory monitoring | Factory Floor, Production Line, Quality Control |
| Building | Building automation, facilities | Building Overview, HVAC, Energy Management |
| Environmental | Weather, air quality | Environmental Monitoring, Weather Station |
| Fleet | Vehicle tracking, logistics | Fleet Overview, Vehicle Details |
| Energy | Power, utilities | Energy Dashboard, Power Quality |
| Equipment | Asset monitoring | Equipment Health, Predictive Maintenance |

## 11.2 Template: Factory Floor Monitoring

```json
{
  "name": "Factory Floor Monitoring",
  "description": "Real-time monitoring of industrial equipment and production metrics",
  "category": "industrial",
  "thumbnail": "/templates/factory-floor.png",
  "widgets": [
    {
      "type": "stats_card",
      "title": "Active Machines",
      "position": { "x": 0, "y": 0, "w": 3, "h": 1 },
      "dataSource": {
        "type": "devices",
        "filter": { "profileId": "industrial_motor", "status": "active" }
      },
      "config": { "icon": "cog", "color": "green" }
    },
    {
      "type": "stats_card",
      "title": "Active Alerts",
      "position": { "x": 3, "y": 0, "w": 3, "h": 1 },
      "dataSource": {
        "type": "alerts",
        "filter": { "status": "active" }
      },
      "config": { "icon": "alert-triangle", "color": "red" }
    },
    {
      "type": "gauge",
      "title": "Avg Temperature",
      "position": { "x": 6, "y": 0, "w": 3, "h": 2 },
      "dataSource": {
        "type": "latest",
        "deviceProfileId": "temperature_sensor",
        "keys": ["temperature"],
        "aggregation": "avg"
      },
      "config": {
        "min": 0,
        "max": 60,
        "unit": "°C",
        "thresholds": [
          { "value": 40, "color": "yellow" },
          { "value": 50, "color": "red" }
        ]
      }
    },
    {
      "type": "gauge",
      "title": "Avg Humidity",
      "position": { "x": 9, "y": 0, "w": 3, "h": 2 },
      "dataSource": {
        "type": "latest",
        "deviceProfileId": "humidity_sensor",
        "keys": ["humidity"],
        "aggregation": "avg"
      },
      "config": {
        "min": 0,
        "max": 100,
        "unit": "%",
        "thresholds": [
          { "value": 70, "color": "yellow" },
          { "value": 85, "color": "red" }
        ]
      }
    },
    {
      "type": "line_chart",
      "title": "Motor Performance Trend",
      "position": { "x": 0, "y": 1, "w": 6, "h": 3 },
      "dataSource": {
        "type": "timeseries",
        "deviceProfileId": "industrial_motor",
        "keys": ["rpm", "current", "temperature"],
        "timeRange": { "type": "relative", "value": "24h" },
        "interval": "5m",
        "aggregation": "avg"
      },
      "config": {
        "showLegend": true,
        "showGrid": true
      }
    },
    {
      "type": "alarm_table",
      "title": "Active Alerts",
      "position": { "x": 0, "y": 4, "w": 6, "h": 2 },
      "dataSource": {
        "type": "alerts",
        "filter": { "status": ["active", "acknowledged"] }
      },
      "config": {
        "columns": ["severity", "device", "message", "time", "actions"],
        "pageSize": 5
      }
    },
    {
      "type": "device_map",
      "title": "Equipment Layout",
      "position": { "x": 6, "y": 2, "w": 6, "h": 4 },
      "dataSource": {
        "type": "devices",
        "filter": { "profileId": ["industrial_motor", "temperature_sensor"] }
      },
      "config": {
        "mapStyle": "light",
        "showStatusColors": true,
        "clusterDevices": false
      }
    }
  ]
}
```

## 11.3 Template: Smart Building Overview

```json
{
  "name": "Smart Building Overview",
  "description": "Building automation and environmental monitoring dashboard",
  "category": "building",
  "widgets": [
    {
      "type": "value_card",
      "title": "Current Occupancy",
      "position": { "x": 0, "y": 0, "w": 2, "h": 1 },
      "dataSource": {
        "type": "latest",
        "deviceProfileId": "occupancy_sensor",
        "keys": ["count"],
        "aggregation": "sum"
      },
      "config": { "unit": "people", "icon": "users" }
    },
    {
      "type": "value_card",
      "title": "Power Usage",
      "position": { "x": 2, "y": 0, "w": 2, "h": 1 },
      "dataSource": {
        "type": "latest",
        "deviceProfileId": "power_meter",
        "keys": ["power"],
        "aggregation": "sum"
      },
      "config": { "unit": "kW", "icon": "zap" }
    },
    {
      "type": "gauge",
      "title": "Avg Temperature",
      "position": { "x": 4, "y": 0, "w": 2, "h": 2 },
      "dataSource": {
        "type": "latest",
        "deviceProfileId": "hvac_unit",
        "keys": ["supply_temp"],
        "aggregation": "avg"
      },
      "config": { "min": 16, "max": 30, "unit": "°C" }
    },
    {
      "type": "gauge",
      "title": "Avg CO2",
      "position": { "x": 6, "y": 0, "w": 2, "h": 2 },
      "dataSource": {
        "type": "latest",
        "deviceProfileId": "air_quality_sensor",
        "keys": ["co2"],
        "aggregation": "avg"
      },
      "config": {
        "min": 400,
        "max": 2000,
        "unit": "ppm",
        "thresholds": [
          { "value": 1000, "color": "yellow" },
          { "value": 1500, "color": "red" }
        ]
      }
    },
    {
      "type": "bar_chart",
      "title": "Energy by Floor",
      "position": { "x": 8, "y": 0, "w": 4, "h": 2 },
      "dataSource": {
        "type": "latest",
        "deviceProfileId": "power_meter",
        "keys": ["energy"],
        "groupBy": "floor"
      },
      "config": { "orientation": "horizontal" }
    },
    {
      "type": "line_chart",
      "title": "Temperature & Humidity Trend",
      "position": { "x": 0, "y": 2, "w": 6, "h": 3 },
      "dataSource": {
        "type": "timeseries",
        "deviceProfileId": "hvac_unit",
        "keys": ["supply_temp", "return_temp"],
        "timeRange": { "type": "relative", "value": "24h" },
        "interval": "15m"
      }
    },
    {
      "type": "line_chart",
      "title": "Air Quality Trend",
      "position": { "x": 6, "y": 2, "w": 6, "h": 3 },
      "dataSource": {
        "type": "timeseries",
        "deviceProfileId": "air_quality_sensor",
        "keys": ["co2", "pm25"],
        "timeRange": { "type": "relative", "value": "24h" },
        "interval": "15m"
      }
    }
  ]
}
```

## 11.4 Template: Fleet Overview

```json
{
  "name": "Fleet Overview",
  "description": "Vehicle tracking and fleet management dashboard",
  "category": "fleet",
  "widgets": [
    {
      "type": "stats_card",
      "title": "Vehicles Moving",
      "position": { "x": 0, "y": 0, "w": 2, "h": 1 },
      "dataSource": {
        "type": "devices",
        "filter": {
          "profileId": "vehicle_gps",
          "telemetry": { "speed": { "gt": 0 } }
        }
      }
    },
    {
      "type": "stats_card",
      "title": "Vehicles Idle",
      "position": { "x": 2, "y": 0, "w": 2, "h": 1 },
      "dataSource": {
        "type": "devices",
        "filter": {
          "profileId": "vehicle_gps",
          "telemetry": { "speed": { "eq": 0 } }
        }
      }
    },
    {
      "type": "device_map",
      "title": "Live Vehicle Locations",
      "position": { "x": 0, "y": 1, "w": 8, "h": 5 },
      "dataSource": {
        "type": "devices",
        "filter": { "profileId": "vehicle_gps" }
      },
      "config": {
        "mapStyle": "streets",
        "showStatusColors": true,
        "clusterDevices": true,
        "popupFields": ["name", "speed", "driver"]
      }
    },
    {
      "type": "device_table",
      "title": "Vehicle Status",
      "position": { "x": 8, "y": 0, "w": 4, "h": 3 },
      "dataSource": {
        "type": "devices",
        "filter": { "profileId": "vehicle_gps" }
      },
      "config": {
        "columns": ["name", "speed", "fuel_level", "status"],
        "pageSize": 10
      }
    },
    {
      "type": "alarm_table",
      "title": "Vehicle Alerts",
      "position": { "x": 8, "y": 3, "w": 4, "h": 3 },
      "dataSource": {
        "type": "alerts",
        "filter": {
          "deviceProfileId": ["vehicle_gps", "vehicle_obd"],
          "status": "active"
        }
      }
    }
  ]
}
```

## 11.5 Template: Equipment Health

```json
{
  "name": "Equipment Health",
  "description": "Predictive maintenance and equipment monitoring",
  "category": "industrial",
  "widgets": [
    {
      "type": "stats_card",
      "title": "Healthy",
      "position": { "x": 0, "y": 0, "w": 2, "h": 1 },
      "dataSource": {
        "type": "devices",
        "filter": { "health": "good" }
      },
      "config": { "color": "green" }
    },
    {
      "type": "stats_card",
      "title": "Warning",
      "position": { "x": 2, "y": 0, "w": 2, "h": 1 },
      "dataSource": {
        "type": "devices",
        "filter": { "health": "warning" }
      },
      "config": { "color": "yellow" }
    },
    {
      "type": "stats_card",
      "title": "Critical",
      "position": { "x": 4, "y": 0, "w": 2, "h": 1 },
      "dataSource": {
        "type": "devices",
        "filter": { "health": "critical" }
      },
      "config": { "color": "red" }
    },
    {
      "type": "anomaly_chart",
      "title": "Vibration Analysis",
      "position": { "x": 0, "y": 1, "w": 6, "h": 3 },
      "dataSource": {
        "type": "timeseries",
        "deviceProfileId": "industrial_motor",
        "keys": ["vibration"],
        "timeRange": { "type": "relative", "value": "7d" }
      },
      "config": {
        "showAnomalies": true,
        "anomalyMethod": "zscore",
        "sensitivity": "medium"
      }
    },
    {
      "type": "ai_insight",
      "title": "Maintenance Predictions",
      "position": { "x": 6, "y": 1, "w": 6, "h": 3 },
      "dataSource": {
        "type": "ai",
        "insightType": "predictive_maintenance",
        "deviceProfileId": "industrial_motor"
      }
    },
    {
      "type": "device_table",
      "title": "Equipment Status",
      "position": { "x": 0, "y": 4, "w": 12, "h": 2 },
      "dataSource": {
        "type": "devices",
        "filter": { "profileId": "industrial_motor" }
      },
      "config": {
        "columns": ["name", "rpm", "temperature", "vibration", "health", "last_maintenance"],
        "sortBy": "health"
      }
    }
  ]
}
```

---

# 12. Project Structure

```
iot-dashboard/
├── app/                                # Next.js App Router
│   ├── (auth)/                        # Auth pages (no main layout)
│   │   ├── login/page.tsx
│   │   ├── register/page.tsx
│   │   ├── setup/page.tsx             # New user tenant setup
│   │   └── layout.tsx
│   │
│   ├── (dashboard)/                   # Main app (with layout)
│   │   ├── layout.tsx                 # App shell with sidebar
│   │   ├── page.tsx                   # Overview/Home
│   │   │
│   │   ├── dashboards/
│   │   │   ├── page.tsx               # Dashboard list
│   │   │   ├── new/page.tsx           # Create dashboard
│   │   │   └── [id]/
│   │   │       ├── page.tsx           # View dashboard
│   │   │       └── edit/page.tsx      # Edit dashboard (builder)
│   │   │
│   │   ├── devices/
│   │   │   ├── page.tsx               # Device list
│   │   │   ├── new/page.tsx           # Add device
│   │   │   └── [id]/page.tsx          # Device details
│   │   │
│   │   ├── alerts/
│   │   │   ├── page.tsx               # Alert list
│   │   │   └── rules/page.tsx         # Alert rules
│   │   │
│   │   ├── hierarchy/
│   │   │   └── page.tsx               # Site > Building > Floor > Area
│   │   │
│   │   ├── ai/
│   │   │   ├── assistant/page.tsx     # AI Chat interface
│   │   │   └── insights/page.tsx      # AI Insights dashboard
│   │   │
│   │   └── settings/
│   │       ├── page.tsx               # General settings
│   │       ├── users/page.tsx         # User management
│   │       ├── roles/page.tsx         # Role management
│   │       ├── profiles/page.tsx      # Device profiles
│   │       ├── api-keys/page.tsx      # API key management
│   │       └── export/page.tsx        # Data export
│   │
│   ├── public/[token]/                # Public dashboard view
│   │   └── page.tsx
│   │
│   └── api/                           # API Routes
│       ├── auth/[...nextauth]/route.ts
│       ├── trpc/[trpc]/route.ts
│       ├── v1/                        # REST API
│       │   ├── devices/route.ts
│       │   ├── telemetry/route.ts
│       │   ├── dashboards/route.ts
│       │   ├── alerts/route.ts
│       │   └── export/route.ts
│       ├── realtime/route.ts          # Socket.io upgrade
│       ├── webhook/telemetry/route.ts # Device telemetry webhook
│       └── ai/
│           ├── query/route.ts
│           ├── dashboard/route.ts
│           └── insights/route.ts
│
├── components/
│   ├── ui/                            # shadcn/ui components
│   │   ├── button.tsx
│   │   ├── card.tsx
│   │   ├── dialog.tsx
│   │   ├── dropdown-menu.tsx
│   │   ├── input.tsx
│   │   ├── select.tsx
│   │   ├── table.tsx
│   │   └── ...
│   │
│   ├── layout/                        # Layout components
│   │   ├── app-shell.tsx
│   │   ├── sidebar.tsx
│   │   ├── header.tsx
│   │   ├── page-header.tsx
│   │   └── breadcrumb.tsx
│   │
│   ├── widgets/                       # Dashboard widgets
│   │   ├── base/
│   │   │   ├── widget-wrapper.tsx
│   │   │   ├── widget-header.tsx
│   │   │   └── widget-loading.tsx
│   │   ├── charts/
│   │   │   ├── line-chart.tsx
│   │   │   ├── area-chart.tsx
│   │   │   ├── bar-chart.tsx
│   │   │   └── pie-chart.tsx
│   │   ├── values/
│   │   │   ├── gauge.tsx
│   │   │   ├── value-card.tsx
│   │   │   └── stats-card.tsx
│   │   ├── tables/
│   │   │   ├── alarm-table.tsx
│   │   │   └── device-table.tsx
│   │   ├── controls/
│   │   │   ├── control-button.tsx
│   │   │   └── control-slider.tsx
│   │   ├── maps/
│   │   │   └── device-map.tsx
│   │   └── ai/
│   │       ├── insight-widget.tsx
│   │       └── anomaly-chart.tsx
│   │
│   ├── builder/                       # Dashboard builder
│   │   ├── dashboard-canvas.tsx
│   │   ├── widget-palette.tsx
│   │   ├── property-panel.tsx
│   │   ├── data-source-picker.tsx
│   │   └── ai-assistant.tsx
│   │
│   ├── devices/                       # Device components
│   │   ├── device-card.tsx
│   │   ├── device-tree.tsx
│   │   └── command-panel.tsx
│   │
│   ├── alerts/                        # Alert components
│   │   ├── alert-list.tsx
│   │   └── alert-rule-form.tsx
│   │
│   ├── ai/                            # AI components
│   │   ├── chat-interface.tsx
│   │   ├── suggestion-card.tsx
│   │   └── insight-panel.tsx
│   │
│   └── shared/                        # Shared components
│       ├── data-table.tsx
│       ├── time-range-picker.tsx
│       ├── device-selector.tsx
│       └── empty-state.tsx
│
├── lib/
│   ├── api/                           # API utilities
│   │   └── client.ts
│   ├── hooks/                         # Custom hooks
│   │   ├── useWidgetData.ts
│   │   ├── useSocket.ts
│   │   └── usePermission.ts
│   ├── stores/                        # Zustand stores
│   │   ├── useAppStore.ts
│   │   └── useDashboardStore.ts
│   ├── utils/                         # Utilities
│   │   ├── cn.ts
│   │   ├── formatters.ts
│   │   └── validators.ts
│   └── widgets/                       # Widget registry
│       └── registry.ts
│
├── server/
│   ├── routers/                       # tRPC routers
│   │   ├── _app.ts
│   │   ├── auth.ts
│   │   ├── device.ts
│   │   ├── dashboard.ts
│   │   ├── alert.ts
│   │   ├── telemetry.ts
│   │   └── ai.ts
│   │
│   ├── services/                      # Business logic
│   │   ├── tenant.service.ts
│   │   ├── device.service.ts
│   │   ├── telemetry.service.ts
│   │   ├── alert.service.ts
│   │   ├── notification.service.ts
│   │   └── ai/
│   │       ├── dashboard-generator.ts
│   │       ├── data-query.ts
│   │       ├── anomaly-detector.ts
│   │       └── alert-summarizer.ts
│   │
│   ├── db/
│   │   ├── schema.prisma
│   │   ├── migrations/
│   │   └── tenant-manager.ts
│   │
│   └── realtime/
│       ├── server.ts
│       └── handlers/
│
├── types/                             # TypeScript types
│   ├── index.ts
│   ├── device.ts
│   ├── dashboard.ts
│   ├── widget.ts
│   └── alert.ts
│
├── config/
│   ├── site.ts
│   ├── dashboard-templates.ts
│   └── device-profiles.ts
│
├── public/
│   ├── icons/
│   └── templates/
│
├── benthos/                           # Stream processing
│   └── telemetry-pipeline.yaml
│
├── k8s/                               # Kubernetes manifests
│   ├── namespace.yaml
│   ├── app/
│   ├── databases/
│   └── monitoring/
│
├── simulator/                         # Device Simulator (separate)
│   ├── package.json
│   ├── src/
│   │   ├── core/
│   │   ├── generators/
│   │   ├── adapters/
│   │   └── scenarios/
│   └── web/
│
├── docker-compose.yml
├── Dockerfile
├── package.json
├── tsconfig.json
├── tailwind.config.ts
├── next.config.js
└── README.md
```

---

# 13. Implementation Priorities

## Phase 1: Foundation (Weeks 1-4)

| Week | Tasks |
|------|-------|
| 1 | Project setup (Next.js 15, TypeScript, Tailwind, shadcn/ui) |
| 1 | Database setup (PostgreSQL, TimescaleDB, Prisma) |
| 2 | Authentication (Auth.js with Google OAuth) |
| 2 | Multi-tenant foundation (master DB, tenant DBs) |
| 3 | User management, RBAC |
| 3 | Location hierarchy (Sites → Buildings → Floors → Areas) |
| 4 | Device profiles and templates |
| 4 | Basic device CRUD |

## Phase 2: Dashboard System (Weeks 5-8)

| Week | Tasks |
|------|-------|
| 5 | Dashboard CRUD |
| 5 | Widget registry and base components |
| 6 | Chart widgets (line, area, bar) |
| 6 | Value widgets (gauge, card) |
| 7 | Dashboard builder UI (grid, drag-drop) |
| 7 | Data source configuration |
| 8 | Real-time updates (Socket.io) |
| 8 | Widget property panel |

## Phase 3: Device Communication (Weeks 9-11)

| Week | Tasks |
|------|-------|
| 9 | MQTT broker setup (EMQX) |
| 9 | MQTT ingestion pipeline |
| 10 | HTTP webhook endpoint |
| 10 | TimescaleDB storage and aggregation |
| 11 | Device commands (RPC) |
| 11 | Gateway support |

## Phase 4: Alerting (Weeks 12-14)

| Week | Tasks |
|------|-------|
| 12 | Alert rules engine |
| 12 | Alert rule UI |
| 13 | Notification channels (email, in-app, webhook) |
| 13 | Alert management UI |
| 14 | Push notifications |
| 14 | Simple rule engine |

## Phase 5: AI Features (Weeks 15-18)

| Week | Tasks |
|------|-------|
| 15 | Claude API integration |
| 15 | Natural language dashboard builder |
| 16 | Natural language data queries |
| 16 | AI assistant chat interface |
| 17 | Anomaly detection (statistical) |
| 17 | Alert summarization |
| 18 | Smart suggestions |
| 18 | Predictive maintenance |

## Phase 6: Advanced Features (Weeks 19-22)

| Week | Tasks |
|------|-------|
| 19 | Public dashboards |
| 19 | Dashboard templates |
| 20 | Data export (CSV, JSON, Excel, PDF) |
| 20 | REST API and API keys |
| 21 | Audit logging |
| 21 | Cold storage archival |
| 22 | Performance optimization |
| 22 | Testing and bug fixes |

## Phase 7: Simulator (Weeks 23-24)

| Week | Tasks |
|------|-------|
| 23 | Simulator core engine |
| 23 | Device profile templates |
| 24 | Anomaly scenarios |
| 24 | Simulator web UI |

---

# 14. Environment Variables

```bash
# .env.example

# Application
NEXT_PUBLIC_APP_URL=http://localhost:3000
NEXTAUTH_URL=http://localhost:3000
NEXTAUTH_SECRET=generate-a-secret-here

# OAuth - Google
GOOGLE_CLIENT_ID=your-google-client-id
GOOGLE_CLIENT_SECRET=your-google-client-secret

# Databases
DATABASE_URL=postgresql://postgres:postgres@localhost:5432/iot_master
TIMESCALE_URL=postgresql://postgres:postgres@localhost:5433/iot_telemetry

# Redis
REDIS_URL=redis://localhost:6379

# Kafka/Redpanda
KAFKA_BROKERS=localhost:19092

# MQTT
MQTT_URL=mqtt://localhost:1883
MQTT_WS_URL=ws://localhost:8083

# AI
ANTHROPIC_API_KEY=your-anthropic-api-key

# Email
RESEND_API_KEY=your-resend-api-key

# Push Notifications
VAPID_PUBLIC_KEY=your-vapid-public-key
VAPID_PRIVATE_KEY=your-vapid-private-key

# Object Storage
S3_ENDPOINT=http://localhost:9000
S3_ACCESS_KEY=minioadmin
S3_SECRET_KEY=minioadmin
S3_BUCKET=iot-exports

# Feature Flags
ENABLE_AI_FEATURES=true
ENABLE_PUSH_NOTIFICATIONS=true
```

---

**End of Technical Specification**

*This document provides the complete technical foundation for implementing the IoT Dashboard Self-Service System using Claude Code CLI.*
